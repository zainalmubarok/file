  <div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>

  <?php
    $su = explode('.',$_SERVER[HTTP_HOST]);
      if (strlen($su[0]) > 2){
        $st = 'us';
      }else{
        $st = $su[0];
      }
    $lg = $this->uri->language($st);  
  ?>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in Countries</h5>
        <div class="justify-content-between align-items-center">
            
            <div class="table-responsive">
              <table width="100%">
                <tr>
                    <td width="50%"><a href="https://opportunie.com/" title="Jobs Opportunities in United States"> United States </a></td>
                    <td width="50%"><a href="https://ar.opportunie.com/" title="Jobs Opportunities in  Argentina"> Argentina</a></td>
                </tr>
                <tr>
                    <td><a href="https://at.opportunie.com/" title="Jobs Opportunities in  Austria"> Austria</a></td>
                    <td><a href="https://au.opportunie.com/" title="Jobs Opportunities in  Australia"> Australia</a></td>
                </tr>
                <tr>
                    <td><a href="https://be.opportunie.com/" title="Jobs Opportunities in  Belgium"> Belgium</a></td>
                    <td><a href="https://bh.opportunie.com/" title="Jobs Opportunities in  Bahrain"> Bahrain</a></td>
                </tr>
                <tr>
                    <td><a href="https://br.opportunie.com/" title="Jobs Opportunities in  Brazil"> Brazil</a></td>
                    <td><a href="https://ca.opportunie.com/" title="Jobs Opportunities in  Canada"> Canada</a></td>
                </tr>
                <tr>
                    <td><a href="https://ch.opportunie.com/" title="Jobs Opportunities in  Switzerland"> Switzerland</a></td>
                    <td><a href="https://cl.opportunie.com/" title="Jobs Opportunities in  Chile"> Chile</a></td>
                </tr>
                <tr>
                    <td><a href="https://cn.opportunie.com/" title="Jobs Opportunities in  China"> China</a></td>
                    <td><a href="https://co.opportunie.com/" title="Jobs Opportunities in  Colombia"> Colombia</a></td>
                </tr>
                <tr>
                    <td><a href="https://cz.opportunie.com/" title="Jobs Opportunities in  Czech Republic"> Czech Republic</a></td>
                    <td><a href="https://de.opportunie.com/" title="Jobs Opportunities in  Germany"> Germany</a></td>
                </tr>
                <tr>
                    <td><a href="https://dk.opportunie.com/" title="Jobs Opportunities in  Denmark"> Denmark</a></td>
                    <td><a href="https://es.opportunie.com/" title="Jobs Opportunities in  Spain"> Spain</a></td>
                </tr>
                <tr>
                    <td><a href="https://fr.opportunie.com/" title="Jobs Opportunities in  France"> France</a></td>
                    <td><a href="https://gr.opportunie.com/" title="Jobs Opportunities in  Greece"> Greece</a></td>
                </tr>
                <tr>
                    <td><a href="https://vn.opportunie.com/" title="Jobs Opportunities in  Vietnam"> Vietnam</a></td>
                    <td><a href="https://hk.opportunie.com/" title="Jobs Opportunities in  Hong Kong"> Hong Kong</a></td>
                </tr>
                <tr>
                    <td><a href="https://hu.opportunie.com/" title="Jobs Opportunities in  Hungary"> Hungary</a></td>
                    <td><a href="https://id.opportunie.com/" title="Jobs Opportunities in  Indonesia"> Indonesia</a></td>
                </tr>
                <tr>
                    <td><a href="https://ie.opportunie.com/" title="Jobs Opportunities in  Ireland"> Ireland</a></td>
                    <td><a href="https://in.opportunie.com/" title="Jobs Opportunities in  India"> India</a></td>
                </tr>
                <tr>
                    <td><a href="https://it.opportunie.com/" title="Jobs Opportunities in  Italy"> Italy</a></td>
                    <td><a href="https://jp.opportunie.com/" title="Jobs Opportunities in  Japan"> Japan</a></td>
                </tr>
                <tr>
                    <td><a href="https://kr.opportunie.com/" title="Jobs Opportunities in  Korea"> Korea</a></td>
                    <td><a href="https://kw.opportunie.com/" title="Jobs Opportunities in  Kuwait"> Kuwait</a></td>
                </tr>
                <tr>
                    <td><a href="https://lu.opportunie.com/" title="Jobs Opportunities in  Luxembourg"> Luxembourg</a></td>
                    <td><a href="https://mx.opportunie.com/" title="Jobs Opportunities in  Mexico"> Mexico</a></td>
                </tr>
                <tr>
                    <td><a href="https://my.opportunie.com/" title="Jobs Opportunities in  Malaysia"> Malaysia</a></td>
                    <td><a href="https://nl.opportunie.com/" title="Jobs Opportunities in  Netherlands"> Netherlands</a></td>
                </tr>
                <tr>
                    <td><a href="https://no.opportunie.com/" title="Jobs Opportunities in  Norway"> Norway</a></td>
                    <td><a href="https://nz.opportunie.com/" title="Jobs Opportunities in  New Zealand"> New Zealand</a></td>
                </tr>
                <tr>
                    <td><a href="https://om.opportunie.com/" title="Jobs Opportunities in  Oman"> Oman</a></td>
                    <td><a href="https://pe.opportunie.com/" title="Jobs Opportunities in  Peru"> Peru</a></td>
                </tr>
                <tr>
                    <td><a href="https://za.opportunie.com/" title="Jobs Opportunities in  South Africa"> South Africa</a></td>
                    <td><a href="https://pk.opportunie.com/" title="Jobs Opportunities in  Pakistan"> Pakistan</a></td>
                </tr>
                <tr>
                    <td><a href="https://pl.opportunie.com/" title="Jobs Opportunities in  Poland"> Poland</a></td>
                    <td><a href="https://pt.opportunie.com/" title="Jobs Opportunities in  Portugal"> Portugal</a></td>
                </tr>
                <tr>
                    <td><a href="https://qt.opportunie.com/" title="Jobs Opportunities in  Qatar"> Qatar</a></td>
                    <td><a href="https://ro.opportunie.com/" title="Jobs Opportunities in  Romania"> Romania</a></td>
                </tr>
                <tr>
                    <td><a href="https://ru.opportunie.com/" title="Jobs Opportunities in  Russia"> Russia</a></td>
                    <td><a href="https://sa.opportunie.com/" title="Jobs Opportunities in  Saudi Arabia"> Saudi Arabia</a></td>
                </tr>
                <tr>
                    <td><a href="https://se.opportunie.com/" title="Jobs Opportunities in  Sweden"> Sweden</a></td>
                    <td><a href="https://sg.opportunie.com/" title="Jobs Opportunities in  Singapore"> Singapore</a></td>
                </tr>
                <tr>
                    <td><a href="https://th.opportunie.com/" title="Jobs Opportunities in  Thailand"> Thailand</a></td>
                    <td><a href="https://tr.opportunie.com/" title="Jobs Opportunities in  Turkey"> Turkey</a></td>
                </tr>
                <tr>
                    <td><a href="https://tw.opportunie.com/" title="Jobs Opportunities in  Taiwan"> Taiwan</a></td>
                    <td><a href="https://gb.opportunie.com/" title="Jobs Opportunities in  United Kingdom"> United Kingdom</a></td>
                </tr>
                <tr>
                    <td><a href="https://ua.opportunie.com/" title="Jobs Opportunities in  Ukraine"> Ukraine</a></td>
                    <td>&nbsp;</td>
                </tr>
              </table>
            </div>
            
            
            <!--
            <ul class="list-group list-group-flush">
                <li class="list-group-item erd"><a href="https://au.opportunie.com/" title="Jobs Opportunities in Australia"> Australia </a></li>
                <li class="list-group-item erd"><a href="https://br.opportunie.com/" title="Jobs Opportunities in Brazil"> Brazil </a></li>
                <li class="list-group-item erd"><a href="https://ca.opportunie.com/" title="Jobs Opportunities in Canada"> Canada </a></li>
                <li class="list-group-item erd"><a href="https://cn.opportunie.com/" title="Jobs Opportunities in China"> China </a></li>
                <li class="list-group-item erd"><a href="https://de.opportunie.com/" title="Jobs Opportunities in Germany"> Germany </a></li>
                <li class="list-group-item erd"><a href="https://in.opportunie.com/" title="Jobs Opportunities in India"> India </a></li>
                <li class="list-group-item erd"><a href="https://id.opportunie.com/" title="Jobs Opportunities in Indonesia"> Indonesia </a></li>
                <li class="list-group-item erd"><a href="https://jp.opportunie.com/" title="Jobs Opportunities in Japan"> Japan </a></li>
                <li class="list-group-item erd"><a href="https://my.opportunie.com/" title="Jobs Opportunities in Malaysia"> Malaysia </a></li>
                <li class="list-group-item erd"><a href="https://mx.opportunie.com/" title="Jobs Opportunities in Mexico"> Mexico </a></li>
                <li class="list-group-item erd"><a href="https://nz.opportunie.com/" title="Jobs Opportunities in New Zealand"> New Zealand </a></li>
                <li class="list-group-item erd"><a href="https://ru.opportunie.com/" title="Jobs Opportunities in Russian"> Russian </a></li>
                <li class="list-group-item erd"><a href="https://sg.opportunie.com/" title="Jobs Opportunities in Singapore"> Singapore </a></li>
                <li class="list-group-item erd"><a href="https://se.opportunie.com/" title="Jobs Opportunities in Sweden"> Sweden </a></li>
                <li class="list-group-item erd"><a href="https://ch.opportunie.com/" title="Jobs Opportunities in Switzerland"> Switzerland </a></li>
                <li class="list-group-item erd"><a href="https://opportunie.com/" title="Jobs Opportunities in United States"> United States </a></li>
            </ul>
            -->
            
    
          <!--<form action="" method="post">
            <select style="width: 100%;" name="countries" onchange="this.form.submit()">
                    <option <?php echo ($st == "au") ? 'selected="selected"' : ''; ?> value="au">Australia</option>
                    <option <?php echo ($st == "br") ? 'selected="selected"' : ''; ?> value="br">Brazil</option>
                    <option <?php echo ($st == "ca") ? 'selected="selected"' : ''; ?> value="ca">Canada</option>
                    <option <?php echo ($st == "cn") ? 'selected="selected"' : ''; ?> value="cn">China</option>
                    <option <?php echo ($st == "de") ? 'selected="selected"' : ''; ?> value="de">Germany</option>
                    <option <?php echo ($st == "in") ? 'selected="selected"' : ''; ?> value="in">India</option>
                    <option <?php echo ($st == "id") ? 'selected="selected"' : ''; ?> value="id">Indonesia</option>
                    <option <?php echo ($st == "jp") ? 'selected="selected"' : ''; ?> value="jp">Japan</option>
                    <option <?php echo ($st == "my") ? 'selected="selected"' : ''; ?> value="my">Malaysia</option>
                    <option <?php echo ($st == "mx") ? 'selected="selected"' : ''; ?> value="mx">Mexico</option>
                    <option <?php echo ($st == "nz") ? 'selected="selected"' : ''; ?> value="nz">New Zealand</option>
                    <option <?php echo ($st == "ru") ? 'selected="selected"' : ''; ?> value="ru">Russian</option>
                    <option <?php echo ($st == "sg") ? 'selected="selected"' : ''; ?> value="sg">Singapore</option>
                    <option <?php echo ($st == "se") ? 'selected="selected"' : ''; ?> value="se">Sweden</option>
                    <option <?php echo ($st == "ch") ? 'selected="selected"' : ''; ?> value="ch">Switzerland</option>
                    <option <?php echo ($st == "gb") ? 'selected="selected"' : ''; ?> value="gb">United Kingdom</option>
                    <option <?php echo ($st == "us") ? 'selected="selected"' : ''; ?> value="us">United States</option>
              </select>
          </form>-->

        </div>
      </div>
    </div>
  </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Type Of Jobs</h5>
        <div class="justify-content-between align-items-center">

          <ul class="list-group list-group-flush">
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l28']?>" title="<?=$lg['l28']?> " ><?=ucwords(strtolower($lg['l28']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              / 
              <a href="<?=@base_url()?>job/type/internship" title="Internship " >Internship </a>
<?php } ?>
          </li>
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l29']?>" title="<?=$lg['l29']?> " ><?=ucwords(strtolower($lg['l29']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              /
              <a href="<?=@base_url()?>job/type/permanent" title="Permanent " >Permanent </a>
<?php } ?>
          </li>
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l30']?>" title="<?=$lg['l30']?> " ><?=ucwords(strtolower($lg['l30']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              /
              <a href="<?=@base_url()?>job/type/volunteer" title="Volunteer " >Volunteer </a>
<?php } ?>
          </li>
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l31']?>" title="<?=$lg['l31']?> " ><?=ucwords(strtolower($lg['l31']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              /
              <a href="<?=@base_url()?>job/type/temporary" title="Temporary " >Temporary </a>
<?php } ?>
          </li>
          
          </ul>

          <ul class="list-group list-group-flush">
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l32']?>" title="<?=$lg['l32']?> " ><?=ucwords(strtolower($lg['l32']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              / 
              <a href="<?=@base_url()?>job/type/contract" title="Contract " >Contract </a>
<?php } ?>
          </li>
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l33']?>" title="<?=$lg['l33']?> " ><?=ucwords(strtolower($lg['l33']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              /
              <a href="<?=@base_url()?>job/type/subcontract" title="Subcontract " >Subcontract </a>
<?php } ?>
          </li>
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l34']?>" title="<?=$lg['l34']?> " ><?=ucwords(strtolower($lg['l34']))?> </a> 
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              /
              <a href="<?=@base_url()?>job/type/new-grad" title="New Grad " >New Graduates </a>
<?php } ?>
          </li>
          <li class="list-group-item">
              <a href="<?=@base_url()?>job/type/<?=$lg['l35']?>" title="<?=$lg['l35']?> " ><?=ucwords(strtolower($lg['l35']))?> </a>
<?php if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){ ?>
              /
              <a href="<?=@base_url()?>job/type/part-time" title="Part time " >Part time </a>
<?php } ?>
          </li>
          
          </ul>

        </div>
      </div>
    </div>
  </div>


</div>