<?php
	$su = explode('.',$_SERVER[HTTP_HOST]);
	if (strlen($su[0]) > 2){
		$st = 'us';
	}else{
		$st = $su[0];
	}
	$lg = $this->uri->language($st);	
?><?php
if (strlen($su[0]) > 2){
?>  

<div class="col-md-12" style="margin-top: 10px;">
  <div class="card mb-12 box-shadow">
    <div class="card-body">
      <h5>Find a Jobs in States</h5>
      <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/alabama" title="view posts under state Alabama">Alabama</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/alaska" title="view posts under state Alaska">Alaska</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/arizona" title="view posts under state Arizona">Arizona</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/arkansas" title="view posts under state Arkansas">Arkansas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/california" title="view posts under state California">California</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/colorado" title="view posts under state Colorado">Colorado</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/connecticut" title="view posts under state Connecticut">Connecticut</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/delaware" title="view posts under state Delaware">Delaware</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/florida" title="view posts under state Florida">Florida</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/georgia" title="view posts under state Georgia">Georgia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hawaii" title="view posts under state Hawaii">Hawaii</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/idaho" title="view posts under state Idaho">Idaho</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/illinois" title="view posts under state Illinois">Illinois</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/indiana" title="view posts under state Indiana">Indiana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/iowa" title="view posts under state Iowa">Iowa</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kansas" title="view posts under state Kansas">Kansas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kentucky" title="view posts under state Kentucky">Kentucky</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/louisiana" title="view posts under state Louisiana">Louisiana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/maine" title="view posts under state Maine">Maine</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/maryland" title="view posts under state Maryland">Maryland</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/massachusetts" title="view posts under state Massachusetts">Massachusetts</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/michigan" title="view posts under state Michigan">Michigan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/minnesota" title="view posts under state Minnesota">Minnesota</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mississippi" title="view posts under state Mississippi">Mississippi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/missouri" title="view posts under state Missouri">Missouri</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/montana" title="view posts under state Montana">Montana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nebraska" title="view posts under state Nebraska">Nebraska</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nevada" title="view posts under state Nevada">Nevada</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-hampshire" title="view posts under state New Hampshire">New Hampshire</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-jersey" title="view posts under state New Jersey">New Jersey</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-mexico" title="view posts under state New Mexico">New Mexico</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-york" title="view posts under state New York">New York</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/north-carolina" title="view posts under state North Carolina">North Carolina</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/north-dakota" title="view posts under state North Dakota">North Dakota</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ohio" title="view posts under state Ohio">Ohio</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/oklahoma" title="view posts under state Oklahoma">Oklahoma</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/oregon" title="view posts under state Oregon">Oregon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pennsylvania" title="view posts under state Pennsylvania">Pennsylvania</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rhode-island" title="view posts under state Rhode Island">Rhode Island</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/south-carolina" title="view posts under state South Carolina">South Carolina</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/south-dakota" title="view posts under state South Dakota">South Dakota</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tennessee" title="view posts under state Tennessee">Tennessee</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/texas" title="view posts under state Texas">Texas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/utah" title="view posts under state Utah">Utah</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/vermont" title="view posts under state Vermont">Vermont</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/virginia" title="view posts under state Virginia">Virginia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/washington" title="view posts under state Washington">Washington</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/west-virginia" title="view posts under state West Virginia">West Virginia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/wisconsin" title="view posts under state Wisconsin">Wisconsin</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/wyoming" title="view posts under state Wyoming">Wyoming</a>	<br />

        </div>
    </div>
  </div>
</div>


<div class="col-md-12" style="margin-top: 10px;">
  <div class="card mb-12 box-shadow">
    <div class="card-body">
      <h5>Find a Jobs Category</h5>
      <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="view posts under category Biotech">Biotech
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/broadcast-journalism" title="view posts under category Broadcast - Journalism">Broadcast - Journalism
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/business-development" title="view posts under category Business Development">Business Development
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/education-teaching" title="view posts under category Education - Teaching">Education - Teaching
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/entry-level-new-grad" title="view posts under category Entry Level - New Grad">Entry Level - New Grad
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/executive" title="view posts under category Executive">Executive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/facilities" title="view posts under category Facilities">Facilities
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="view posts under category Franchise ">Franchise 
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/human-resources" title="view posts under category Human Resources">Human Resources
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/information-technology" title="view posts under category Information Technology">Information Technology
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/installation-maint-repair" title="view posts under category Installation - Maint - Repair">Installation - Maint - Repair
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/insurance" title="view posts under category Insurance">Insurance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/inventory" title="view posts under category Inventory">Inventory
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal" title="view posts under category Legal">Legal
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="view posts under category Legal Admin">Legal Admin
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/management" title="view posts under category Management">Management
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/manufacturing" title="view posts under category Manufacturing">Manufacturing
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="view posts under category Marketing">Marketing
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/media-journalism-newspaper" title="view posts under category Media - Journalism - Newspaper">Media - Journalism - Newspaper
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/nonprofit-social-services" title="view posts under category Nonprofit - Social Services">Nonprofit - Social Services
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/nurse" title="view posts under category Nurse ">Nurse 
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/other" title="view posts under category Other">Other
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/pharmaceutical" title="view posts under category Pharmaceutical">Pharmaceutical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/professional-services" title="view posts under category Professional Services">Professional Services
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/purchasing-procurement" title="view posts under category Purchasing - Procurement">Purchasing - Procurement
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/qa-quality-control" title="view posts under category QA - Quality Control">QA - Quality Control
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/real-estate" title="view posts under category Real Estate">Real Estate
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/research" title="view posts under category Research">Research
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-food-service" title="view posts under category Restaurant - Food Service">Restaurant - Food Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/science" title="view posts under category Science">Science
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/skilled-labor-trades" title="view posts under category Skilled Labor - Trades">Skilled Labor - Trades
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/strategy-planning" title="view posts under category Strategy - Planning">Strategy - Planning
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/supply-chain" title="view posts under category Supply Chain">Supply Chain
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecommunications" title="view posts under category Telecommunications">Telecommunications
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/training" title="view posts under category Training">Training
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warehouse" title="view posts under category Warehouse">Warehouse
  </a>
	<?php
}
?>
      </div>
    </div>
  </div>
</div>

<?php
if ($st == 'id'){
?>

<div class="col-md-12" style="margin-top: 10px;">
  <div class="card mb-12 box-shadow">
    <div class="card-body">
      <h5>Find a Jobs in City</h5>
      <div class="justify-content-between align-items-center">

       	  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banda-aceh" title="Lowongan Di Kota Banda Aceh">Banda Aceh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/langsa" title="Lowongan Di Kota Langsa">Langsa</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/lhokseumawe" title="Lowongan Di Kota Lhokseumawe">Lhokseumawe</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/meulaboh" title="Lowongan Di Kota Meulaboh">Meulaboh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sabang" title="Lowongan Di Kota Sabang">Sabang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/subulussalam" title="Lowongan Di Kota Subulussalam">Subulussalam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/denpasar" title="Lowongan Di Kota Denpasar">Denpasar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pangkalpinang" title="Lowongan Di Kota Pangkalpinang">Pangkalpinang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/cilegon" title="Lowongan Di Kota Cilegon">Cilegon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/serang" title="Lowongan Di Kota Serang">Serang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tangerang-selatan" title="Lowongan Di Kota Tangerang Selatan">Tangerang Selatan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tangerang" title="Lowongan Di Kota Tangerang">Tangerang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bengkulu" title="Lowongan Di Kota Bengkulu">Bengkulu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/gorontalo" title="Lowongan Di Kota Gorontalo">Gorontalo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-barat" title="Lowongan Di Kota Jakarta Barat">Jakarta Barat</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-pusat" title="Lowongan Di Kota Jakarta Pusat">Jakarta Pusat</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-selatan" title="Lowongan Di Kota Jakarta Selatan">Jakarta Selatan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-timur" title="Lowongan Di Kota Jakarta Timur">Jakarta Timur</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-utara" title="Lowongan Di Kota Jakarta Utara">Jakarta Utara</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sungai-penuh" title="Lowongan Di Kota Sungai Penuh">Sungai Penuh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jambi" title="Lowongan Di Kota Jambi">Jambi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bandung" title="Lowongan Di Kota Bandung">Bandung</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bekasi" title="Lowongan Di Kota Bekasi">Bekasi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bogor" title="Lowongan Di Kota Bogor">Bogor</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/cimahi" title="Lowongan Di Kota Cimahi">Cimahi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/cirebon" title="Lowongan Di Kota Cirebon">Cirebon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/depok" title="Lowongan Di Kota Depok">Depok</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sukabumi" title="Lowongan Di Kota Sukabumi">Sukabumi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tasikmalaya" title="Lowongan Di Kota Tasikmalaya">Tasikmalaya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banjar" title="Lowongan Di Kota Banjar">Banjar</a>
		  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/magelang" title="Lowongan Di Kota Magelang">Magelang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pekalongan" title="Lowongan Di Kota Pekalongan">Pekalongan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/purwokerto" title="Lowongan Di Kota Purwokerto">Purwokerto</a>	
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/salatiga" title="Lowongan Di Kota Salatiga">Salatiga</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/semarang" title="Lowongan Di Kota Semarang">Semarang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/surakarta" title="Lowongan Di Kota Surakarta">Surakarta</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tegal" title="Lowongan Di Kota Tegal">Tegal</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/batu" title="Lowongan Di Kota Batu">Batu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/blitar" title="Lowongan Di Kota Blitar">Blitar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kediri" title="Lowongan Di Kota Kediri">Kediri</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/madiun" title="Lowongan Di Kota Madiun">Madiun</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/malang" title="Lowongan Di Kota Malang">Malang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mojokerto" title="Lowongan Di Kota Mojokerto">Mojokerto</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pasuruan" title="Lowongan Di Kota Pasuruan">Pasuruan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/probolinggo" title="Lowongan Di Kota Probolinggo">Probolinggo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/surabaya" title="Lowongan Di Kota Surabaya">Surabaya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pontianak" title="Lowongan Di Kota Pontianak">Pontianak</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/singkawang" title="Lowongan Di Kota Singkawang">Singkawang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banjarbaru" title="Lowongan Di Kota Banjarbaru">Banjarbaru</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banjarmasin" title="Lowongan Di Kota Banjarmasin">Banjarmasin</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palangkaraya" title="Lowongan Di Kota Palangkaraya">Palangkaraya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/balikpapan" title="Lowongan Di Kota Balikpapan">Balikpapan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bontang" title="Lowongan Di Kota Bontang">Bontang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/samarinda" title="Lowongan Di Kota Samarinda">Samarinda</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tarakan" title="Lowongan Di Kota Tarakan">Tarakan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/batam" title="Lowongan Di Kota Batam">Batam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tanjungpinang" title="Lowongan Di Kota Tanjungpinang">Tanjungpinang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bandar-lampung" title="Lowongan Di Kota Bandar Lampung">Bandar Lampung</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/metro" title="Lowongan Di Kota Metro">Metro</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ternate" title="Lowongan Di Kota Ternate">Ternate</a>
		  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tidore-kepulauan" title="Lowongan Di Kota Tidore Kepulauan">Tidore Kepulauan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ambon" title="Lowongan Di Kota Ambon">Ambon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tual" title="Lowongan Di Kota Tual">Tual</a>
   <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bima" title="Lowongan Di Kota Bima">Bima</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mataram" title="Lowongan Di Kota Mataram">Mataram</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kupang" title="Lowongan Di Kota Kupang">Kupang</a>	
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sorong" title="Lowongan Di Kota Sorong">Sorong</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jayapura" title="Lowongan Di Kota Jayapura">Jayapura</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/dumai" title="Lowongan Di Kota Dumai">Dumai</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pekanbaru" title="Lowongan Di Kota Pekanbaru">Pekanbaru</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/makassar" title="Lowongan Di Kota Makassar">Makassar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palopo" title="Lowongan Di Kota Palopo">Palopo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/parepare" title="Lowongan Di Kota Parepare">Parepare</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palu" title="Lowongan Di Kota Palu">Palu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bau-bau" title="Lowongan Di Kota Bau-Bau">Bau-Bau</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kendari" title="Lowongan Di Kota Kendari">Kendari</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bitung" title="Lowongan Di Kota Bitung">Bitung</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kotamobagu" title="Lowongan Di Kota Kotamobagu">Kotamobagu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/manado" title="Lowongan Di Kota Manado">Manado</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tomohon" title="Lowongan Di Kota Tomohon">Tomohon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bukittinggi" title="Lowongan Di Kota Bukittinggi">Bukittinggi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/padang" title="Lowongan Di Kota Padang">Padang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/padangpanjang" title="Lowongan Di Kota Padangpanjang">Padangpanjang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pariaman" title="Lowongan Di Kota Pariaman">Pariaman</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/payakumbuh" title="Lowongan Di Kota Payakumbuh">Payakumbuh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sawahlunto" title="Lowongan Di Kota Sawahlunto">Sawahlunto</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/solok" title="Lowongan Di Kota Solok">Solok</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/lubuklinggau" title="Lowongan Di Kota Lubuklinggau">Lubuklinggau</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pagaralam" title="Lowongan Di Kota Pagaralam">Pagaralam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palembang" title="Lowongan Di Kota Palembang">Palembang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/prabumulih" title="Lowongan Di Kota Prabumulih">Prabumulih</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/binjai" title="Lowongan Di Kota Binjai">Binjai</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/medan" title="Lowongan Di Kota Medan">Medan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/padang-sidempuan" title="Lowongan Di Kota Padang Sidempuan">Padang Sidempuan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pematangsiantar" title="Lowongan Di Kota Pematangsiantar">Pematangsiantar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sibolga" title="Lowongan Di Kota Sibolga">Sibolga</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tanjungbalai" title="Lowongan Di Kota Tanjungbalai">Tanjungbalai</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tebingtinggi" title="Lowongan Di Kota Tebingtinggi">Tebingtinggi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/yogyakarta" title="Lowongan Di Kota Yogyakarta">Yogyakarta</a>
	<?php
}
?>

      </div>
    </div>
  </div>
</div>
