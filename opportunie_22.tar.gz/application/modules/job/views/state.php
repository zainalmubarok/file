<?=@$this->load->view('header')?>

		<?php
			//pertama adalah ambil data
				$pek = clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
				$brow = urlencode($_SERVER['HTTP_USER_AGENT']);
				$ip = urlencode($_SERVER['REMOTE_ADDR']);
				$ofset = 1;
				if ($this->uri->segment(4)){
					$ofset = $this->uri->segment(4);
				}
				$uri1 = 'http://api.indeed.com/ads/apisearch?q='. $pek .'&l=&sort=date&start='. $ofset .'&limit=10&latlong=1&co='. $this->state .'&v=2&publisher='.$this->pubkey.'';
        		/*$uri2 = 'https://elsafarm.com/indeed/ambil/pub_id/'.$this->pubkey.'&pek='. $pek .'&ofset='. $ofset .'&state='. $this->state .'';
        		$uri3 = 'https://rafly.id/zain.php?pub_id='.$this->pubkey.'&pek='. $pek .'&ofset='. $ofset .'&state='. $this->state .'';
        		$uri4 = 'https://bookingwisata.com/indeed/ambil?pub_id='.$this->pubkey.'&pek='. $pek .'&ofset='. $ofset .'&state='. $this->state .'';
        		$uri5 = 'https://bumirahayu.com/zain.php?pub_id='.$this->pubkey.'&pek='. $pek .'&ofset='. $ofset .'&state='. $this->state .'';*/
        		
        		$sxml = simplexml_load_file($uri1);
        		
        		/*if(simplexml_load_file($uri1)) {
        		    $sxml = simplexml_load_file($uri1);
        		    $x_s = 'XmlServ_1';
        		}elseif(simplexml_load_file($uri2)){
        		    $sxml = simplexml_load_file($uri2);
        		    $x_s = 'XmlServ_2';
        		}elseif(simplexml_load_file($uri3)){
        		    $sxml = simplexml_load_file($uri3);
        		    $x_s = 'XmlServ_3';
        		}elseif(simplexml_load_file($uri4)){
        		    $sxml = simplexml_load_file($uri4);
        		    $x_s = 'XmlServ_4';
        		}else{
        		    $sxml = simplexml_load_file($uri5);
        		    $x_s = 'XmlServ_5';
        		}*/
				
				$dat = $sxml->results;
						$config['total_rows'] 		= $sxml->totalresults;
						$config['per_page'] 		= 20;
						$config['use_page_numbers'] = false;
						$config['base_url'] 		= base_url ('job/'. $this->u2 .'/'. $this->u3);
						$config['uri_segment'] 		= 4;
						$config['full_tag_open'] 	= '<ul class="pagination">';
						$config['full_tag_close'] 	= '</ul>';
						$config['first_link'] 		= 'First';
						$config['first_tag_open'] 	= '<li class="page-item">';
						$config['first_tag_close'] 	= '</li>';
						$config['last_link'] 		= 'Last';
						$config['last_tag_open'] 	= '<li class="page-item">';
						$config['last_tag_close'] 	= '</li>';
						$config['next_link'] 		= 'Next';
						$config['next_tag_open'] 	= '<li class="page-item">';
						$config['next_tag_close'] 	= '</li>';
						$config['prev_link'] 		= 'Previous';
						$config['prev_tag_open'] 	= '<li class="page-item">';
						$config['prev_tag_close'] 	= '</li>';
						$config['cur_tag_open'] 	= '<li class="page-item"><a class="active page-link">';
						$config['cur_tag_close'] 	= '</a></li>';
						$config['num_tag_open'] 	= '<li class="page-item">';
						$config['num_tag_close'] 	= '</li>';
						$this->pagination->initialize($config);
						$data['halaman'] 			= $this->pagination->create_links();
						$data['total'] 				= $config['total_rows'];
		?>
		<?php
									$su = explode('.',$_SERVER[HTTP_HOST]);
									if (strlen($su[0]) > 2){
										$st = 'us';
									}else{
										$st = $su[0];
									}
									$lg = $this->uri->language($st);	
									?>
<!-- Main -->
<div id="main">

	<div class="row" style="margin-left: 0px; margin-right: 0px;">
		<div class="col-md-6" style="padding-right: 0px;">
		<br>
		
		<hr>
		<div class="col-md-12">
		    <h2 class="related-title"><?=@ucwords($pek)?> <?=@ucwords($lg['l10'])?></h2>
		</div>

		<?php
			if($dat){
			foreach($dat->result as $opt){
			$urtmbh = strtolower(SchCleanChar($opt->jobtitle));
			$urtmbh = urlencode(str_replace(' ', '-', $urtmbh)) . '.html';
		?>

			<div class="col-md-12">
				<div class="card mb-12 box-shadow" style="margin-top: 10px;">
					<div class="card-body">
						<a href="<?=@base_url('job/article/'. $opt->jobkey .'/'. $urtmbh)?>" title="<?=@$opt->jobtitle?>" target="_blank">
						<h3><?=@$opt->jobtitle?></h3>
						</a>
					<p class="card-text">
						<?=@$opt->snippet?>
					</p>
					<?php
						//buat city dan company
						$company = clean_data(urlencode(strtolower(str_replace(" ", "-", SchCleanChar($opt->company)))));
						$city = clean_data(urlencode(strtolower(str_replace(" ", "-", SchCleanChar($opt->formattedLocation)))));
					?>
						<div class="d-flex justify-content-between align-items-center">
							<div class="btn-group">
								<a href="<?=@base_url('job/company/'. $company)?>" title="view posts under company <?=@$opt->company?>">
									<button type="button" class="btn btn-sm btn-outline-secondary"><?=@$opt->company?></button>
								</a>&nbsp;
								<a href="<?=@base_url('job/city/'. $city)?>" title="view posts under city <?=@$opt->formattedLocation?>">
									<button type="button" class="btn btn-sm btn-outline-secondary"><?=@$opt->formattedLocation?></button>
								</a>
							</div>
							<small class="text-muted"><?=@$opt->formattedRelativeTime?></small>
						</div>
					</div>
				</div>
			</div>

		<?php } ?>
		<?php } ?>

			<div class="col-md-12">
				<div class="card-body">
					<?=@$data['halaman']?><br />
				</div>
			</div>
		</div>

		

		<?=@$this->load->view('list')?>

		<?=@$this->load->view('sidebar')?>

	</div>

</div>

				

			</div>

		<?=@$this->load->view('footer')?>

		<!-- Scripts -->
		<script src="<?php echo base_url();?>assets/jquery/jquery.slim.min.js"></script>
		<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>

	</body>
</html>