<?php
	if($this->uri->segment(3) != 'sitemap.xml'){
		redirect(base_url());
	}
	header("Content-type: text/xml; charset=utf-8");
	$aa = "<?";
	$bb = "?>";
	$cc = 'xml version="1.0" encoding="UTF-8"';
	echo $aa . $cc . $bb;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<url>
  <loc>https://opportunie.com/</loc>
  <changefreq>hourly</changefreq>
  <priority>1.0</priority>
</url>
<?php 
	$brow = urlencode($_SERVER['HTTP_USER_AGENT']);
	$ip = urlencode($_SERVER['REMOTE_ADDR']);
	//$uri = 'http://api.indeed.com/ads/apisearch?publisher='.$this->pubkey.'&q=a&l=&sort=date&radius=&st=&jt=&start=0&limit=100&fromage=&filter=&latlong=1&co='. $this->state .'&chnl=&userip='. $ip .'&useragent='. $brow .'&v=2';
	//$sxml = simplexml_load_file($uri);
	
	$uri1 = 'http://api.indeed.com/ads/apisearch?q=a&l=&sort=date&start=0&limit=50&latlong=1&co='. $this->state .'&v=2&publisher='.$this->pubkey.'';
	/*$uri2 = 'https://elsafarm.com/indeed/ambil/pub_id/'.$this->pubkey.'&pek=a&ofset=0&state='. $this->state .'';
	$uri3 = 'https://rafly.id/zain.php?pub_id='.$this->pubkey.'&pek=a&ofset=0&state='. $this->state .'';
	$uri4 = 'https://bookingwisata.com/indeed/ambil?pub_id='.$this->pubkey.'&pek='. $pek .'&ofset='. $ofset .'&state='. $this->state .'';
	$uri5 = 'https://bumirahayu.com/zain.php?pub_id='.$this->pubkey.'&pek=a&ofset=0&state='. $this->state .'';*/
	
	$sxml = simplexml_load_file($uri1);
	
	/*if(simplexml_load_file($uri1)) {
	    $sxml = simplexml_load_file($uri1);
	    $x_s = 'XmlServ_1';
	}elseif(simplexml_load_file($uri2)){
	    $sxml = simplexml_load_file($uri2);
	    $x_s = 'XmlServ_2';
	}elseif(simplexml_load_file($uri3)){
	    $sxml = simplexml_load_file($uri3);
	    $x_s = 'XmlServ_3';
	}elseif(simplexml_load_file($uri4)){
	    $sxml = simplexml_load_file($uri4);
	    $x_s = 'XmlServ_4';
	}else{
	    $sxml = simplexml_load_file($uri5);
	    $x_s = 'XmlServ_5';
	}*/
				
	$dat = $sxml->results;
	foreach($dat->result as $opt){
		$urtmbh = strtolower(SchCleanChar($opt->jobtitle));
		$urtmbh = urlencode(str_replace(' ', '-', $urtmbh)) . '.html';
		$dt = 'date';
?>
<url>
  <loc><?=@base_url('job/article/'. $opt->jobkey .'/'. $urtmbh)?></loc>
  <changefreq>hourly</changefreq>
  <priority>1.0</priority>
</url>
<?php } ?>
<?php 
	$brow = urlencode($_SERVER['HTTP_USER_AGENT']);
	$ip = urlencode($_SERVER['REMOTE_ADDR']);
	//$uri = 'http://api.indeed.com/ads/apisearch?publisher='.$this->pubkey.'&q=a&l=&sort=date&radius=&st=&jt=&start=50&limit=25&fromage=&filter=&latlong=1&co='. $this->state .'&chnl=&userip='. $ip .'&useragent='. $brow .'&v=2';
	//$sxml = simplexml_load_file($uri);
	$uri1 = 'http://api.indeed.com/ads/apisearch?q=a&l=&sort=date&start=0&limit=50&latlong=1&co='. $this->state .'&v=2&publisher='.$this->pubkey.'';
	/*$uri2 = 'https://elsafarm.com/indeed/ambil/pub_id/'.$this->pubkey.'&pek=a&ofset=0&state='. $this->state .'';
	$uri3 = 'https://rafly.id/zain.php?pub_id='.$this->pubkey.'&pek=a&ofset=0&state='. $this->state .'';
	$uri4 = 'https://bookingwisata.com/indeed/ambil?pub_id='.$this->pubkey.'&pek='. $pek .'&ofset='. $ofset .'&state='. $this->state .'';
	$uri5 = 'https://bumirahayu.com/zain.php?pub_id='.$this->pubkey.'&pek=a&ofset=0&state='. $this->state .'';*/
	
	$sxml = simplexml_load_file($uri1);
	
	/*if(simplexml_load_file($uri1)) {
	    $sxml = simplexml_load_file($uri1);
	    $x_s = 'XmlServ_1';
	}elseif(simplexml_load_file($uri2)){
	    $sxml = simplexml_load_file($uri2);
	    $x_s = 'XmlServ_2';
	}elseif(simplexml_load_file($uri3)){
	    $sxml = simplexml_load_file($uri3);
	    $x_s = 'XmlServ_3';
	}elseif(simplexml_load_file($uri4)){
	    $sxml = simplexml_load_file($uri4);
	    $x_s = 'XmlServ_4';
	}else{
	    $sxml = simplexml_load_file($uri5);
	    $x_s = 'XmlServ_5';
	}*/
	
	$dat = $sxml->results;
	foreach($dat->result as $opt){
		$urtmbh = strtolower(SchCleanChar($opt->jobtitle));
		$urtmbh = urlencode(str_replace(' ', '-', $urtmbh)) . '.html';
		$dt = 'date';
?>
<url>
  <loc><?=@base_url('job/article/'. $opt->jobkey .'/'. $urtmbh)?></loc>
  <lastmod><?=@date("Y-m-d", strtotime($opt->$dt))?>T<?=@date("H:i:s", strtotime($opt->$dt))?>+00:00</lastmod>
  <changefreq>hourly</changefreq>
  <priority>1.0</priority>
</url>
<?php } ?>
</urlset>