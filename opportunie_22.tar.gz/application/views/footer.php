<br />
	<script type="text/javascript">
			function logout(url){  
				$.messager.confirm('Konfirmasi', 'Apakah anda yakin akan keluar?', function(r){
					if (r){
						window.location.href = url;
					}
				});
			}
			function gantipassword(){
				$('#gantipass').modal('show');
			}
			function gantiyuk(){
				var a = $('#passlama').val();
				var b = $('#passbaru').val();
				var c = $('#konfirmasi').val();
				if(a == ''){
					$.messager.alert('Informasi', 'Password lama harus diisi', 'info');
				} else if(b == ''){
					$.messager.alert('Informasi', 'Password baru harus diisi', 'info');
				} else if(c == ''){
					$.messager.alert('Informasi', 'Konfirmasi password harus diisi', 'info');
				} else if (b != c) {
					$.messager.alert('Informasi', 'Konfirmasi password tidak sama', 'info');
				} else {
					$.post("<?=base_url('login/gantipass')?>", {
						userid: '<?=@$this->session->userdata('id_log')?>', passlama: a, passbaru: b, 
					}, function(response){
						if(response == 'simpan'){
							$.messager.alert('Informasi', 'Passworad berhasil diganti', 'info');
							$('#gantipass').hide('slow');
							setTimeout(function(){ window.location.href = location.href; }, 1000);
						} else {
							$.messager.alert('Informasi', response, 'info');
						}
					});
				}
			}
	</script>
		<div id="gantipass" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="width:50%;margin: 0 0 0 -25%;">	
			<div class="modal-header"><h4>Form Ganti Password / <?=@ucwords($this->session->userdata('nm_log'))?></h4>
			</div>
			<div class="modal-body">
			<em><p>Silahkan Masukkan Password Baru dan Verifikasi</p></em>
					<table>
						<tr>
							<td width="40%"><p>Password Lama</p></td>
							<td>
								<input type="password" name="passlama" id="passlama" value="" />
							</td>
						</tr>
						<tr>
							<td><p>Password Baru</p></td>
							<td>
								<input type="password" name="passbaru" id="passbaru" value="" />
							</td>
						</tr>
						<tr>
							<td><p>Konfirmasi</p></td>
							<td>
								<input type="password" name="konfirmasi" id="konfirmasi" value="" />
							</td>
						</tr>
					</table>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" onclick="gantiyuk()" name="ganti">Ganti Password</button>
				<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
			</div>
		</div>
<div class="atasfooter"></div>
	<div id="footer" style="z-index:999999">
		<div class="container">
						<?php
							echo "Total Exec Time: " . $this->benchmark->elapsed_time('total_execution_time_start','total_execution_time_end') .' | ';
							//
							//echo "Base Class Load Time: " . $this->benchmark->elapsed_time('loading_time:_base_classes_start','loading_time:_base_classes_end') .' | ';
							//
							$class = $this->router->fetch_class();
							$method = $this->router->fetch_method();
							echo "Controller / Method ( {$class} / {$method} ) Exec Time: " . $this->benchmark->elapsed_time('controller_execution_time_( '.$class.' / '.$method.' )_start','controller_execution_time_( '.$class.' / '.$method.' )_end') .'';
							//
							//echo "Total Query Exec Time: " . number_format($this->db->benchmark,4); 
						?>
			<p class="text-muted credit pull-right">
			Powered by: <a href="" onclick="return false">CV. Vikosha Perdana</a> | <small>Versi <?=@$this->mglobal->get_setting('is_version')?></small></p>
		</div>
    </div>
  </body>
</html>