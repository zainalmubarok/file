<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2011, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */

// ------------------------------------------------------------------------

/**
 * URI Class
 *
 * Parses URIs and determines routing
 *
 * @package		CodeIgniter
 * @subpackage	Libraries
 * @category	URI
 * @author		ExpressionEngine Dev Team
 * @link		http://codeigniter.com/user_guide/libraries/uri.html
 */
class CI_URI {

	/**
	 * List of cached uri segments
	 *
	 * @var array
	 * @access public
	 */
	var	$keyval			= array();
	/**
	 * Current uri string
	 *
	 * @var string
	 * @access public
	 */
	var $uri_string;
	/**
	 * List of uri segments
	 *
	 * @var array
	 * @access public
	 */
	var $segments		= array();
	/**
	 * Re-indexed list of uri segments
	 * Starts at 1 instead of 0
	 *
	 * @var array
	 * @access public
	 */
	var $rsegments		= array();

	/**
	 * Constructor
	 *
	 * Simply globalizes the $RTR object.  The front
	 * loads the Router class early on so it's not available
	 * normally as other classes are.
	 *
	 * @access	public
	 */
	function __construct()
	{
		$this->config =& load_class('Config', 'core');
		log_message('debug', "URI Class Initialized");
	}


	// --------------------------------------------------------------------

	/**
	 * Get the URI String
	 *
	 * @access	private
	 * @return	string
	 */
	function _fetch_uri_string()
	{
		if (strtoupper($this->config->item('uri_protocol')) == 'AUTO')
		{
			// Is the request coming from the command line?
			if (php_sapi_name() == 'cli' or defined('STDIN'))
			{
				$this->_set_uri_string($this->_parse_cli_args());
				return;
			}

			// Let's try the REQUEST_URI first, this will work in most situations
			if ($uri = $this->_detect_uri())
			{
				$this->_set_uri_string($uri);
				return;
			}

			// Is there a PATH_INFO variable?
			// Note: some servers seem to have trouble with getenv() so we'll test it two ways
			$path = (isset($_SERVER['PATH_INFO'])) ? $_SERVER['PATH_INFO'] : @getenv('PATH_INFO');
			if (trim($path, '/') != '' && $path != "/".SELF)
			{
				$this->_set_uri_string($path);
				return;
			}

			// No PATH_INFO?... What about QUERY_STRING?
			$path =  (isset($_SERVER['QUERY_STRING'])) ? $_SERVER['QUERY_STRING'] : @getenv('QUERY_STRING');
			if (trim($path, '/') != '')
			{
				$this->_set_uri_string($path);
				return;
			}

			// As a last ditch effort lets try using the $_GET array
			if (is_array($_GET) && count($_GET) == 1 && trim(key($_GET), '/') != '')
			{
				$this->_set_uri_string(key($_GET));
				return;
			}

			// We've exhausted all our options...
			$this->uri_string = '';
			return;
		}

		$uri = strtoupper($this->config->item('uri_protocol'));

		if ($uri == 'REQUEST_URI')
		{
			$this->_set_uri_string($this->_detect_uri());
			return;
		}
		elseif ($uri == 'CLI')
		{
			$this->_set_uri_string($this->_parse_cli_args());
			return;
		}

		$path = (isset($_SERVER[$uri])) ? $_SERVER[$uri] : @getenv($uri);
		$this->_set_uri_string($path);
	}

	// --------------------------------------------------------------------

	/**
	 * Set the URI String
	 *
	 * @access	public
	 * @param 	string
	 * @return	string
	 */
	function _set_uri_string($str)
	{
		// Filter out control characters
		$str = remove_invisible_characters($str, FALSE);

		// If the URI contains only a slash we'll kill it
		$this->uri_string = ($str == '/') ? '' : $str;
	}

	// --------------------------------------------------------------------

	/**
	 * Detects the URI
	 *
	 * This function will detect the URI automatically and fix the query string
	 * if necessary.
	 *
	 * @access	private
	 * @return	string
	 */
	private function _detect_uri()
	{
		if ( ! isset($_SERVER['REQUEST_URI']) OR ! isset($_SERVER['SCRIPT_NAME']))
		{
			return '';
		}

		$uri = $_SERVER['REQUEST_URI'];
		if (strpos($uri, $_SERVER['SCRIPT_NAME']) === 0)
		{
			$uri = substr($uri, strlen($_SERVER['SCRIPT_NAME']));
		}
		elseif (strpos($uri, dirname($_SERVER['SCRIPT_NAME'])) === 0)
		{
			$uri = substr($uri, strlen(dirname($_SERVER['SCRIPT_NAME'])));
		}

		// This section ensures that even on servers that require the URI to be in the query string (Nginx) a correct
		// URI is found, and also fixes the QUERY_STRING server var and $_GET array.
		if (strncmp($uri, '?/', 2) === 0)
		{
			$uri = substr($uri, 2);
		}
		$parts = preg_split('#\?#i', $uri, 2);
		$uri = $parts[0];
		if (isset($parts[1]))
		{
			$_SERVER['QUERY_STRING'] = $parts[1];
			parse_str($_SERVER['QUERY_STRING'], $_GET);
		}
		else
		{
			$_SERVER['QUERY_STRING'] = '';
			$_GET = array();
		}

		if ($uri == '/' || empty($uri))
		{
			return '/';
		}

		$uri = parse_url($uri, PHP_URL_PATH);

		// Do some final cleaning of the URI and return it
		return str_replace(array('//', '../'), '/', trim($uri, '/'));
	}

	// --------------------------------------------------------------------

	/**
	 * Parse cli arguments
	 *
	 * Take each command line argument and assume it is a URI segment.
	 *
	 * @access	private
	 * @return	string
	 */
	private function _parse_cli_args()
	{
		$args = array_slice($_SERVER['argv'], 1);

		return $args ? '/' . implode('/', $args) : '';
	}

	// --------------------------------------------------------------------

	/**
	 * Filter segments for malicious characters
	 *
	 * @access	private
	 * @param	string
	 * @return	string
	 */
	function _filter_uri($str)
	{
		if ($str != '' && $this->config->item('permitted_uri_chars') != '' && $this->config->item('enable_query_strings') == FALSE)
		{
			// preg_quote() in PHP 5.3 escapes -, so the str_replace() and addition of - to preg_quote() is to maintain backwards
			// compatibility as many are unaware of how characters in the permitted_uri_chars will be parsed as a regex pattern
			if ( ! preg_match("|^[".str_replace(array('\\-', '\-'), '-', preg_quote($this->config->item('permitted_uri_chars'), '-'))."]+$|i", $str))
			{
				show_error('The URI you submitted has disallowed characters.', 400);
			}
		}

		// Convert programatic characters to entities
		$bad	= array('$',		'(',		')',		'%28',		'%29');
		$good	= array('&#36;',	'&#40;',	'&#41;',	'&#40;',	'&#41;');

		return str_replace($bad, $good, $str);
	}

	// --------------------------------------------------------------------

	/**
	 * Remove the suffix from the URL if needed
	 *
	 * @access	private
	 * @return	void
	 */
	function _remove_url_suffix()
	{
		if  ($this->config->item('url_suffix') != "")
		{
			$this->uri_string = preg_replace("|".preg_quote($this->config->item('url_suffix'))."$|", "", $this->uri_string);
		}
	}

	// --------------------------------------------------------------------

	/**
	 * Explode the URI Segments. The individual segments will
	 * be stored in the $this->segments array.
	 *
	 * @access	private
	 * @return	void
	 */
	function _explode_segments()
	{
		foreach (explode("/", preg_replace("|/*(.+?)/*$|", "\\1", $this->uri_string)) as $val)
		{
			// Filter segments for security
			$val = trim($this->_filter_uri($val));

			if ($val != '')
			{
				$this->segments[] = $val;
			}
		}
	}

	// --------------------------------------------------------------------
	/**
	 * Re-index Segments
	 *
	 * This function re-indexes the $this->segment array so that it
	 * starts at 1 rather than 0.  Doing so makes it simpler to
	 * use functions like $this->uri->segment(n) since there is
	 * a 1:1 relationship between the segment array and the actual segments.
	 *
	 * @access	private
	 * @return	void
	 */
	function _reindex_segments()
	{
		array_unshift($this->segments, NULL);
		array_unshift($this->rsegments, NULL);
		unset($this->segments[0]);
		unset($this->rsegments[0]);
	}

	// --------------------------------------------------------------------

	/**
	 * Fetch a URI Segment
	 *
	 * This function returns the URI segment based on the number provided.
	 *
	 * @access	public
	 * @param	integer
	 * @param	bool
	 * @return	string
	 */
	function segment($n, $no_result = FALSE)
	{
		return ( ! isset($this->segments[$n])) ? $no_result : $this->segments[$n];
	}

	// --------------------------------------------------------------------

	/**
	 * Fetch a URI "routed" Segment
	 *
	 * This function returns the re-routed URI segment (assuming routing rules are used)
	 * based on the number provided.  If there is no routing this function returns the
	 * same result as $this->segment()
	 *
	 * @access	public
	 * @param	integer
	 * @param	bool
	 * @return	string
	 */
	function rsegment($n, $no_result = FALSE)
	{
		return ( ! isset($this->rsegments[$n])) ? $no_result : $this->rsegments[$n];
	}

	// --------------------------------------------------------------------

	/**
	 * Generate a key value pair from the URI string
	 *
	 * This function generates and associative array of URI data starting
	 * at the supplied segment. For example, if this is your URI:
	 *
	 *	example.com/user/search/name/joe/location/UK/gender/male
	 *
	 * You can use this function to generate an array with this prototype:
	 *
	 * array (
	 *			name => joe
	 *			location => UK
	 *			gender => male
	 *		 )
	 *
	 * @access	public
	 * @param	integer	the starting segment number
	 * @param	array	an array of default values
	 * @return	array
	 */
	function uri_to_assoc($n = 3, $default = array())
	{
		return $this->_uri_to_assoc($n, $default, 'segment');
	}
	/**
	 * Identical to above only it uses the re-routed segment array
	 *
	 * @access 	public
	 * @param 	integer	the starting segment number
	 * @param 	array	an array of default values
	 * @return 	array
	 *
	 */
	function ruri_to_assoc($n = 3, $default = array())
	{
		return $this->_uri_to_assoc($n, $default, 'rsegment');
	}

	// --------------------------------------------------------------------

	/**
	 * Generate a key value pair from the URI string or Re-routed URI string
	 *
	 * @access	private
	 * @param	integer	the starting segment number
	 * @param	array	an array of default values
	 * @param	string	which array we should use
	 * @return	array
	 */
	function _uri_to_assoc($n = 3, $default = array(), $which = 'segment')
	{
		if ($which == 'segment')
		{
			$total_segments = 'total_segments';
			$segment_array = 'segment_array';
		}
		else
		{
			$total_segments = 'total_rsegments';
			$segment_array = 'rsegment_array';
		}

		if ( ! is_numeric($n))
		{
			return $default;
		}

		if (isset($this->keyval[$n]))
		{
			return $this->keyval[$n];
		}

		if ($this->$total_segments() < $n)
		{
			if (count($default) == 0)
			{
				return array();
			}

			$retval = array();
			foreach ($default as $val)
			{
				$retval[$val] = FALSE;
			}
			return $retval;
		}

		$segments = array_slice($this->$segment_array(), ($n - 1));

		$i = 0;
		$lastval = '';
		$retval  = array();
		foreach ($segments as $seg)
		{
			if ($i % 2)
			{
				$retval[$lastval] = $seg;
			}
			else
			{
				$retval[$seg] = FALSE;
				$lastval = $seg;
			}

			$i++;
		}

		if (count($default) > 0)
		{
			foreach ($default as $val)
			{
				if ( ! array_key_exists($val, $retval))
				{
					$retval[$val] = FALSE;
				}
			}
		}

		// Cache the array for reuse
		$this->keyval[$n] = $retval;
		return $retval;
	}

	// --------------------------------------------------------------------

	/**
	 * Generate a URI string from an associative array
	 *
	 *
	 * @access	public
	 * @param	array	an associative array of key/values
	 * @return	array
	 */
	function assoc_to_uri($array)
	{
		$temp = array();
		foreach ((array)$array as $key => $val)
		{
			$temp[] = $key;
			$temp[] = $val;
		}

		return implode('/', $temp);
	}

	// --------------------------------------------------------------------

	/**
	 * Fetch a URI Segment and add a trailing slash
	 *
	 * @access	public
	 * @param	integer
	 * @param	string
	 * @return	string
	 */
	function slash_segment($n, $where = 'trailing')
	{
		return $this->_slash_segment($n, $where, 'segment');
	}

	// --------------------------------------------------------------------

	/**
	 * Fetch a URI Segment and add a trailing slash
	 *
	 * @access	public
	 * @param	integer
	 * @param	string
	 * @return	string
	 */
	function slash_rsegment($n, $where = 'trailing')
	{
		return $this->_slash_segment($n, $where, 'rsegment');
	}

	// --------------------------------------------------------------------

	/**
	 * Fetch a URI Segment and add a trailing slash - helper function
	 *
	 * @access	private
	 * @param	integer
	 * @param	string
	 * @param	string
	 * @return	string
	 */
	function _slash_segment($n, $where = 'trailing', $which = 'segment')
	{
		$leading	= '/';
		$trailing	= '/';

		if ($where == 'trailing')
		{
			$leading	= '';
		}
		elseif ($where == 'leading')
		{
			$trailing	= '';
		}

		return $leading.$this->$which($n).$trailing;
	}

	// --------------------------------------------------------------------

	/**
	 * Segment Array
	 *
	 * @access	public
	 * @return	array
	 */
	function segment_array()
	{
		return $this->segments;
	}

	// --------------------------------------------------------------------

	/**
	 * Routed Segment Array
	 *
	 * @access	public
	 * @return	array
	 */
	function rsegment_array()
	{
		return $this->rsegments;
	}

	// --------------------------------------------------------------------

	/**
	 * Total number of segments
	 *
	 * @access	public
	 * @return	integer
	 */
	function total_segments()
	{
		return count($this->segments);
	}

	// --------------------------------------------------------------------

	/**
	 * Total number of routed segments
	 *
	 * @access	public
	 * @return	integer
	 */
	function total_rsegments()
	{
		return count($this->rsegments);
	}

	// --------------------------------------------------------------------

	/**
	 * Fetch the entire URI string
	 *
	 * @access	public
	 * @return	string
	 */
	function uri_string()
	{
		return $this->uri_string;
	}


	// --------------------------------------------------------------------

	/**
	 * Fetch the entire Re-routed URI string
	 *
	 * @access	public
	 * @return	string
	 */
	function ruri_string()
	{
		return '/'.implode('/', $this->rsegment_array());
	}
	
	function countries($a)
	{
		switch ($a) {
			case "af": $b = "Afghanistan"; break;
			case "al": $b = "Albania"; break;
			case "dz": $b = "Algeria"; break;
			case "ds": $b = "American Samoa"; break;
			case "ad": $b = "Andorra"; break;
			case "ao": $b = "Angola"; break;
			case "ai": $b = "Anguilla"; break;
			case "aq": $b = "Antarctica"; break;
			case "ag": $b = "Antigua and Barbuda"; break;
			case "ar": $b = "Argentina"; break;
			case "am": $b = "Armenia"; break;
			case "aw": $b = "Aruba"; break;
			case "au": $b = "Australia"; break;
			case "at": $b = "Austria"; break;
			case "az": $b = "Azerbaijan"; break;
			case "bs": $b = "Bahamas"; break;
			case "bh": $b = "Bahrain"; break;
			case "bd": $b = "Bangladesh"; break;
			case "bb": $b = "Barbados"; break;
			case "by": $b = "Belarus"; break;
			case "be": $b = "Belgium"; break;
			case "bz": $b = "Belize"; break;
			case "bj": $b = "Benin"; break;
			case "bm": $b = "Bermuda"; break;
			case "bt": $b = "Bhutan"; break;
			case "bo": $b = "Bolivia"; break;
			case "ba": $b = "Bosnia and Herzegovina"; break;
			case "bw": $b = "Botswana"; break;
			case "bv": $b = "Bouvet Island"; break;
			case "br": $b = "Brazil"; break;
			case "io": $b = "British Indian Ocean Territory"; break;
			case "bn": $b = "Brunei Darussalam"; break;
			case "bg": $b = "Bulgaria"; break;
			case "bf": $b = "Burkina Faso"; break;
			case "bi": $b = "Burundi"; break;
			case "kh": $b = "Cambodia"; break;
			case "cm": $b = "Cameroon"; break;
			case "ca": $b = "Canada"; break;
			case "cv": $b = "Cape Verde"; break;
			case "ky": $b = "Cayman Islands"; break;
			case "cf": $b = "Central African Republic"; break;
			case "td": $b = "Chad"; break;
			case "cl": $b = "Chile"; break;
			case "cn": $b = "China"; break;
			case "cx": $b = "Christmas Island"; break;
			case "cc": $b = "Cocos (Keeling) Islands"; break;
			case "co": $b = "Colombia"; break;
			case "km": $b = "Comoros"; break;
			case "cg": $b = "Congo"; break;
			case "ck": $b = "Cook Islands"; break;
			case "cr": $b = "Costa Rica"; break;
			case "hr": $b = "Croatia (Hrvatska)"; break;
			case "cu": $b = "Cuba"; break;
			case "cy": $b = "Cyprus"; break;
			case "cz": $b = "Czech Republic"; break;
			case "dk": $b = "Denmark"; break;
			case "dj": $b = "Djibouti"; break;
			case "dm": $b = "Dominica"; break;
			case "do": $b = "Dominican Republic"; break;
			case "tp": $b = "East Timor"; break;
			case "ec": $b = "Ecuador"; break;
			case "eg": $b = "Egypt"; break;
			case "sv": $b = "El Salvador"; break;
			case "gq": $b = "Equatorial Guinea"; break;
			case "er": $b = "Eritrea"; break;
			case "ee": $b = "Estonia"; break;
			case "et": $b = "Ethiopia"; break;
			case "fk": $b = "Falkland Islands (Malvinas)"; break;
			case "fo": $b = "Faroe Islands"; break;
			case "fj": $b = "Fiji"; break;
			case "fi": $b = "Finland"; break;
			case "fr": $b = "France"; break;
			case "fx": $b = "France, Metropolitan"; break;
			case "gf": $b = "French Guiana"; break;
			case "pf": $b = "French Polynesia"; break;
			case "tf": $b = "French Southern Territories"; break;
			case "ga": $b = "Gabon"; break;
			case "gm": $b = "Gambia"; break;
			case "ge": $b = "Georgia"; break;
			case "de": $b = "Germany"; break;
			case "gh": $b = "Ghana"; break;
			case "gi": $b = "Gibraltar"; break;
			case "gk": $b = "Guernsey"; break;
			case "gr": $b = "Greece"; break;
			case "gl": $b = "Greenland"; break;
			case "gd": $b = "Grenada"; break;
			case "gp": $b = "Guadeloupe"; break;
			case "gu": $b = "Guam"; break;
			case "gt": $b = "Guatemala"; break;
			case "gn": $b = "Guinea"; break;
			case "gw": $b = "Guinea-Bissau"; break;
			case "gy": $b = "Guyana"; break;
			case "ht": $b = "Haiti"; break;
			case "hm": $b = "Heard and Mc Donald Islands"; break;
			case "hn": $b = "Honduras"; break;
			case "hk": $b = "Hong Kong"; break;
			case "hu": $b = "Hungary"; break;
			case "is": $b = "Iceland"; break;
			case "in": $b = "India"; break;
			case "im": $b = "Isle of Man"; break;
			case "id": $b = "Indonesia"; break;
			case "ir": $b = "Iran (Islamic Republic of)"; break;
			case "iq": $b = "Iraq"; break;
			case "ie": $b = "Ireland"; break;
			case "il": $b = "Israel"; break;
			case "it": $b = "Italy"; break;
			case "ci": $b = "Ivory Coast"; break;
			case "je": $b = "Jersey"; break;
			case "jm": $b = "Jamaica"; break;
			case "jp": $b = "Japan"; break;
			case "jo": $b = "Jordan"; break;
			case "kz": $b = "Kazakhstan"; break;
			case "ke": $b = "Kenya"; break;
			case "ki": $b = "Kiribati"; break;
			case "kp": $b = "Korea, Democratic People's Republic of"; break;
			case "kr": $b = "Korea, Republic of"; break;
			case "xk": $b = "Kosovo"; break;
			case "kw": $b = "Kuwait"; break;
			case "kg": $b = "Kyrgyzstan"; break;
			case "la": $b = "Lao People's Democratic Republic"; break;
			case "lv": $b = "Latvia"; break;
			case "lb": $b = "Lebanon"; break;
			case "ls": $b = "Lesotho"; break;
			case "lr": $b = "Liberia"; break;
			case "ly": $b = "Libyan Arab Jamahiriya"; break;
			case "li": $b = "Liechtenstein"; break;
			case "lt": $b = "Lithuania"; break;
			case "lu": $b = "Luxembourg"; break;
			case "mo": $b = "Macau"; break;
			case "mk": $b = "Macedonia"; break;
			case "mg": $b = "Madagascar"; break;
			case "mw": $b = "Malawi"; break;
			case "my": $b = "Malaysia"; break;
			case "mv": $b = "Maldives"; break;
			case "ml": $b = "Mali"; break;
			case "mt": $b = "Malta"; break;
			case "mh": $b = "Marshall Islands"; break;
			case "mq": $b = "Martinique"; break;
			case "mr": $b = "Mauritania"; break;
			case "mu": $b = "Mauritius"; break;
			case "ty": $b = "Mayotte"; break;
			case "mx": $b = "Mexico"; break;
			case "fm": $b = "Micronesia, Federated States of"; break;
			case "md": $b = "Moldova, Republic of"; break;
			case "mc": $b = "Monaco"; break;
			case "mn": $b = "Mongolia"; break;
			case "me": $b = "Montenegro"; break;
			case "ms": $b = "Montserrat"; break;
			case "ma": $b = "Morocco"; break;
			case "mz": $b = "Mozambique"; break;
			case "mm": $b = "Myanmar"; break;
			case "na": $b = "Namibia"; break;
			case "nr": $b = "Nauru"; break;
			case "np": $b = "Nepal"; break;
			case "nl": $b = "Netherlands"; break;
			case "an": $b = "Netherlands Antilles"; break;
			case "nc": $b = "New Caledonia"; break;
			case "nz": $b = "New Zealand"; break;
			case "ni": $b = "Nicaragua"; break;
			case "ne": $b = "Niger"; break;
			case "ng": $b = "Nigeria"; break;
			case "nu": $b = "Niue"; break;
			case "nf": $b = "Norfolk Island"; break;
			case "mp": $b = "Northern Mariana Islands"; break;
			case "no": $b = "Norway"; break;
			case "om": $b = "Oman"; break;
			case "pk": $b = "Pakistan"; break;
			case "pw": $b = "Palau"; break;
			case "ps": $b = "Palestine"; break;
			case "pa": $b = "Panama"; break;
			case "pg": $b = "Papua New Guinea"; break;
			case "py": $b = "Paraguay"; break;
			case "pe": $b = "Peru"; break;
			case "ph": $b = "Philippines"; break;
			case "pn": $b = "Pitcairn"; break;
			case "pl": $b = "Poland"; break;
			case "pt": $b = "Portugal"; break;
			case "pr": $b = "Puerto Rico"; break;
			case "qa": $b = "Qatar"; break;
			case "re": $b = "Reunion"; break;
			case "ro": $b = "Romania"; break;
			case "ru": $b = "Russian Federation"; break;
			case "rw": $b = "Rwanda"; break;
			case "kn": $b = "Saint Kitts and Nevis"; break;
			case "lc": $b = "Saint Lucia"; break;
			case "vc": $b = "Saint Vincent and the Grenadines"; break;
			case "ws": $b = "Samoa"; break;
			case "sm": $b = "San Marino"; break;
			case "st": $b = "Sao Tome and Principe"; break;
			case "sa": $b = "Saudi Arabia"; break;
			case "sn": $b = "Senegal"; break;
			case "rs": $b = "Serbia"; break;
			case "sc": $b = "Seychelles"; break;
			case "sl": $b = "Sierra Leone"; break;
			case "sg": $b = "Singapore"; break;
			case "sk": $b = "Slovakia"; break;
			case "si": $b = "Slovenia"; break;
			case "sb": $b = "Solomon Islands"; break;
			case "so": $b = "Somalia"; break;
			case "za": $b = "South Africa"; break;
			case "gs": $b = "South Georgia South Sandwich Islands"; break;
			case "ss": $b = "South Sudan"; break;
			case "es": $b = "Spain"; break;
			case "lk": $b = "Sri Lanka"; break;
			case "sh": $b = "St. Helena"; break;
			case "pm": $b = "St. Pierre and Miquelon"; break;
			case "sd": $b = "Sudan"; break;
			case "sr": $b = "Suriname"; break;
			case "sj": $b = "Svalbard and Jan Mayen Islands"; break;
			case "sz": $b = "Swaziland"; break;
			case "se": $b = "Sweden"; break;
			case "ch": $b = "Switzerland"; break;
			case "sy": $b = "Syrian Arab Republic"; break;
			case "tw": $b = "Taiwan"; break;
			case "tj": $b = "Tajikistan"; break;
			case "tz": $b = "Tanzania, United Republic of"; break;
			case "th": $b = "Thailand"; break;
			case "tg": $b = "Togo"; break;
			case "tk": $b = "Tokelau"; break;
			case "to": $b = "Tonga"; break;
			case "tt": $b = "Trinidad and Tobago"; break;
			case "tn": $b = "Tunisia"; break;
			case "tr": $b = "Turkey"; break;
			case "tm": $b = "Turkmenistan"; break;
			case "tc": $b = "Turks and Caicos Islands"; break;
			case "tv": $b = "Tuvalu"; break;
			case "ug": $b = "Uganda"; break;
			case "ua": $b = "Ukraine"; break;
			case "ae": $b = "United Arab Emirates"; break;
			case "gb": $b = "United Kingdom"; break;
			case "us": $b = "United States"; break;
			case "um": $b = "United States minor outlying islands"; break;
			case "uy": $b = "Uruguay"; break;
			case "uz": $b = "Uzbekistan"; break;
			case "vu": $b = "Vanuatu"; break;
			case "va": $b = "Vatican City State"; break;
			case "ve": $b = "Venezuela"; break;
			case "vn": $b = "Vietnam"; break;
			case "vg": $b = "Virgin Islands (British)"; break;
			case "vi": $b = "Virgin Islands (U.S.)"; break;
			case "wf": $b = "Wallis and Futuna Islands"; break;
			case "eh": $b = "Western Sahara"; break;
			case "ye": $b = "Yemen"; break;
			case "zr": $b = "Zaire"; break;
			case "zm": $b = "Zambia"; break;
			case "zw": $b = "Zimbabwe"; break;
			default: $b = "United States";
		}
		return $b;
	}
	
	function language($a)
	{
		switch ($a) {
			//case "au": $b = "Australia"; break;
			case "cn": 
				$lang = array(
					'l1'=>'职位空缺',
					'l2'=>'在工作',
					'l3'=>'寻找新工作',
					'l4'=>'乔布斯',
					'l5'=>'工作和空缺',
					'l6'=>'找工作机会,找到你的职业生涯',
					'l7'=>'查找最新',
					'l8'=>'工作',
					'l9'=>'适合你。搜索最新',
					'l10'=>'工作机会',
					'l11'=>'职位空缺',
					'l12'=>'职业',
					'l13'=>'工作',
					'l14'=>'就业',
					'l15'=>'寻找新工作',
					'l16'=>'正在寻找',
					'l17'=>'新工作',
					'l18'=>'找到最新',
					'l19'=>'职位空缺',
					'l20'=>'职位描述',
					'l21'=>'职位列表',
					'l22'=>'工作开放',
					'l23'=>'机遇',
					'l24'=>'in',
					'l25'=>'at',
					'l26'=>'邮政服务',
					'l27'=>'欲了解更多信息,请点击下面的链接',
					'l28'=>'实习',
					'l29'=>'永久',
					'l30'=>'志愿者',
					'l31'=>'临时',
					'l32'=>'合同',
					'l33'=>'转包',
					'l34'=>'新毕业生',
					'l35'=>'兼职',
					'l36'=>'相关工作机会',
					'l37'=>'找到并应用你最好的',
					'l38'=>'这里可用'
				);
				break;
			case "id": 
				$lang = array(
						'l1'  => 'Lowongan Kerja Di',
						'l2' => 'Bekerja di',
						'l3' => 'Mencari Pekerjaan Baru',
						'l4' => 'Pekerjaan di',
						'l5' => 'Pekerjaan & Lowongan di',
						'l6' => 'peluang kerja dan temukan karier Anda di',
						'l7' => 'Temukan yang terbaru',
						'l8' => 'Pekerjaan',
						'l9' => 'tepat untukmu Cari terbaru',
						'l10' => 'kesempatan kerja',
						'l11' => 'lowongan pekerjaan',
						'l12' => 'karier',
						'l13' => 'bekerja di',
						'l14' => 'Pekerjaan di',
						'l15' => 'Mencari Pekerjaan Baru',
						'l16' => 'Mencari',
						'l17' => 'Pekerjaan baru di',
						'l18' => 'Temukan yang terbaru',
						'l19' => 'Lowongan pekerjaan',
						'l20' => 'Deskripsi pekerjaan',
						'l21' => 'daftar pekerjaan',
						'l22' => 'pekerjaan terbuka di',
						'l23' => 'Peluang di',
						'l24' => 'di',
						'l25' => 'pada',
						'l26' => 'Layanan Pos',
						'l27' => 'Untuk informasi lebih lanjut silakan klik tautan di bawah ini',
						'l28' => 'magang',
						'l29' => 'permanen',
						'l30' => 'sukarelawan',
						'l31' => 'sementara',
						'l32' => 'kontrak',
						'l33' => 'kontrak tambahan',
						'l34' => 'baru lulusan',
						'l35' => 'paruh waktu',
						'l36' => 'Peluang Pekerjaan Terkait',
						'l37' => 'Temukan dan terapkan yang terbaik',
						'l38' => 'tersedia disini'
				); 
				break;
			case "jp": 
				$lang = array(
					'l1' => '求人情報の数',
					'l2' => 'うまくいく',
					'l3' => '新しい仕事を探す',
					'l4' => 'ジョブズイン',
					'l5' => 'での求人と求人',
					'l6' => '仕事の機会とあなたのキャリアを見つけてください',
					'l7' => '最新情報を探す',
					'l8' => '仕事',
					'l9' => 'その通りです。最新の検索',
					'l10' => '仕事の機会',
					'l11' => '求人',
					'l12' => 'キャリア',
					'l13' => '作業中',
					'l14' => 'での雇用',
					'l15' => '新しい仕事を探す',
					'l16' => '探しています',
					'l17' => '新規求人',
					'l18' => '最新のものを探す',
					'l19' => '求人',
					'l20' => '仕事の説明',
					'l21' => '求人一覧',
					'l22' => '求人募集中',
					'l23' => 'での機会',
					'l24' => 'in',
					'l25' => 'at',
					'l26' => '郵便サービス',
					'l27' => '詳細については,下のリンクをクリックしてください。',
					'l28' => 'インターンシップ',
					'l29' => '永久',
					'l30' => 'ボランティア',
					'l31' => '一時的',
					'l32' => '契約',
					'l33' => 'サブコントラクト',
					'l34' => '新卒',
					'l35' => 'パートタイム',
					'l36' => '関連する求人の機会',
					'l37' => 'あなたのベストを見つけて応用してください',
					'l38' => 'こちらから入手可能'
				);
				break;
			case "my": 
				$lang = array(
					'l1' => 'Kekosongan Jawatan Di',
					'l2' => 'Bekerja di',
					'l3' => 'Mencari Pekerjaan Baru',
					'l4' => 'Pekerjaan di',
					'l5' => 'Pekerjaan & Kekosongan dalam',
					'l6' => 'peluang pekerjaan dan cari kerjaya anda di',
					'l7' => 'Cari terkini',
					'l8' => 'Pekerjaan',
					'l9' => 'betul untuk anda. Cari terkini ',
					'l10' => 'peluang pekerjaan',
					'l11' => 'kekosongan jawatan',
					'l12' => 'kerjaya',
					'l13' => 'kerja di',
					'l14' => 'Pekerjaan dalam',
					'l15' => 'Mencari Pekerjaan Baru',
					'l16' => 'Mencari',
					'l17' => 'Kerja Baru di',
					'l18' => 'Cari yang terkini',
					'l19' => 'pembukaan kerja',
					'l20' => 'deskripsi pekerjaan',
					'l21' => 'senarai pekerjaan',
					'l22' => 'kerja dibuka di',
					'l23' => 'Peluang dalam',
					'l24' => 'dalam',
					'l25' => 'di',
					'l26' => 'Perkhidmatan Pos',
					'l27' => 'Untuk maklumat lanjut sila klik pautan di bawah',
					'l28' => 'magang',
					'l29' => 'kekal',
					'l30' => 'sukarelawan',
					'l31' => 'sementara',
					'l32' => 'kontrak',
					'l33' => 'subkontrak',
					'l34' => 'lulusan baru',
					'l35' => 'sambilan',
					'l36' => 'Peluang Pekerjaan Terkait',
					'l37' => 'Cari dan gunakan yang terbaik',
					'l38' => 'tersedia di sini'
				);
				break;
			/*case "nz": 
				$lang = array(
				
				);
				break;
			case "sg": 
				$lang = array(
				
				);
				break;
			case "se": 
				$lang = array(
				
				);
				break;
			case "ch": 
				$lang = array(
				
				);
				break;
			case "gb": 
				$lang = array(
				
				);
				break;*/
			default: 
				$lang = array(
						'l1'  => 'Job Vacancies In',
						'l2' => 'Works in',
						'l3' => 'Looking for a New Job',
						'l4' => 'Jobs in',
						'l5' => 'Jobs & Vacancies in',
						'l6' => 'job opportunities and find your career at',
						'l7' => 'Find latest',
						'l8' => 'Jobs',
						'l9' => 'right for you. Search latest',
						'l10' => 'job opportunities',
						'l11' => 'job vacancies',
						'l12' => 'career',
						'l13' => 'work in',
						'l14' => 'Employment in',
						'l15' => 'Looking for a New Job',
						'l16' => 'Looking for',
						'l17' => 'New Job in',
						'l18' => 'Find the latest',
						'l19' => 'job opening',
						'l20' => 'job descriptions',
						'l21' => 'job listing',
						'l22' => 'jobs opening in',
						'l23' => 'Opportunities in',
						'l24' => 'in',
						'l25' => 'at',
						'l26' => 'Postal Service',
						'l27' => 'For more information please click the link below',
						'l28' => 'internship',
						'l29' => 'permanent',
						'l30' => 'volunteer',
						'l31' => 'temporary',
						'l32' => 'contract',
						'l33' => 'subcontract',
						'l34' => 'new graduates',
						'l35' => 'part time',
						'l36' => 'Related Jobs Opportunities',
						'l37' => 'Find and apply your best',
						'l38' => 'available here'
				);
		}
		return $lang;
	}

}
// END URI Class

/* End of file URI.php */
/* Location: ./system/core/URI.php */