<?php

/**
 * CPX Anti Ad Block
 */

if ( !function_exists('sys_get_temp_dir')) {
	function sys_get_temp_dir() { 
	  if( !empty($_ENV['TMP']) ) { return realpath($_ENV['TMP']); } 
	  if( !empty($_ENV['TMPDIR']) ) { return realpath($_ENV['TMPDIR']); } 
	  if( !empty($_ENV['TEMP']) ) { return realpath($_ENV['TEMP']); } 
	  $tempfile = tempnam(__FILE__,''); 
	  if( file_exists($tempfile) ) { 
	    unlink($tempfile); 
	    return realpath(dirname($tempfile)); 
	  } 
	  return null; 
	} 
}

class CPX
{
	private $username = 'caerul';
	private $sourceId = '63988';
	private $popType = '2';
	private $onePer = '1';
	private $freq = '0';
	private $host = 'api.cpx24.net';
	private $cache_folder ='';

	private function method1($url) { // curl
		if( in_array('curl', get_loaded_extensions()) ) {
			$options = array(CURLOPT_URL => 'http://' . $this->host . $url, CURLOPT_RETURNTRANSFER => 1);
			$ch = curl_init();
			curl_setopt_array($ch, $options);
			$response = curl_exec($ch);
			curl_close($ch);
			return $response;
		} else {
			return false;
		}
	}

	private function method2($url) { // file_get_contents
		if( function_exists('file_get_contents') && function_exists('allow_url_fopen') ) {
			$response = file_get_contents('http://' . $this->host . $url);
			return $response;
		} else {
			return false;
		}
	}
	
	private function method3($url) { // fsockopen
		$fs = null;
		$in = '';

		if( !($fs = fsockopen('tcp://' . gethostbyname($this->host), 80, $errno, $errstr, 10)) ) {
			return false;
		}

		$out = "GET " . $url . " HTTP/1.1\r\n";
		$out .= "Host: " . $this->host . "\r\n";
		$out .= "Connection: close\r\n\r\n";
		fwrite( $fs, $out );
		while( !feof($fs) ) $in .= fgets($fs, 1024);
		fclose( $fs );
		return substr($in, strpos($in, "\r\n\r\n") + 4);
	}

	
	public function getCode() {
		$query = array(
										'u' => $this->username,
										'sid' => $this->sourceId,
										'pt' => $this->popType,
										'ot' => $this->onePer,
										'fr' => $this->freq,
										'o1' => 'get_adblock_code',
										'api_key' => 'z2R1d7J4'
									);
		$url = "/pub_api.php?" . http_build_query($query);

		if($this->cache_folder!="")	$file = $this->cache_folder .  '/cpx-code-' . md5($url) . '.js';;
		else 						$file = sys_get_temp_dir() . '/cpx-code-' . md5($url) . '.js';

		if( file_exists($file) && filemtime($file) >= strtotime('-2 hours') ) {
			$code=file_get_contents($file);
			$this->displayCode($code);
			return;
		}

		$code = $this->method1($url);

		if( !$code ) $code = $this->method2($url);

		if ( !$code ) $code = $this->method3($url);

		if ( $code ) {
			if($this->validateCode($code)==true){
				$fp = fopen( "{$file}.tmp", 'wt' );
				fwrite( $fp, $code );
				fclose( $fp );
				rename( "${file}.tmp", $file );
			} else if( file_exists( $file ) ) {
				$code=file_get_contents( $file );				
			}
		}

		$this->displayCode($code);
	}
	
	public function validateCode($code=null) {
		if( stristr( $code, '=undefined') && stristr( $code, 'script')) {
			return true;
		}else{
			return false;
		}
	}

	public function displayCode($code=null) {
		if($code!="" && $this->validateCode($code)==true){
			echo $code;
		}
	}
}


$cpx = new CPX();
$cpx->getCode();