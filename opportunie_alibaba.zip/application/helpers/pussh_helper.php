<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
error_reporting(0);
	if ( !function_exists('SchCleanChar') ){
		function SchCleanChar($result) {
			
			return $result;
		}
	}
	function url_get_contents ($url) {
		if (function_exists('curl_exec')){ 
			$conn = curl_init($url);
			curl_setopt($conn, CURLOPT_SSL_VERIFYPEER, true);
			curl_setopt($conn, CURLOPT_FRESH_CONNECT,  true);
			curl_setopt($conn, CURLOPT_RETURNTRANSFER, 1);
			$url_get_contents_data = (curl_exec($conn));
			curl_close($conn);
		}elseif(function_exists('file_get_contents')){
			$url_get_contents_data = file_get_contents($url);
		}elseif(function_exists('fopen') && function_exists('stream_get_contents')){
			$handle = fopen ($url, "r");
			$url_get_contents_data = stream_get_contents($handle);
		}else{
			$url_get_contents_data = false;
		}
	return $url_get_contents_data;
	} 
	function bantai($url){
		 $data = curl_init();
				 curl_setopt($data, CURLOPT_RETURNTRANSFER, 1);
				 curl_setopt($data, CURLOPT_URL, $url);
				 $hasil = curl_exec($data);
				 curl_close($data);
				 return $hasil;
		}
	if( ! function_exists('ummuValidationInput'))
	{
		function ummuValidationInput($getPost, $getName, $valMin=2, $valMax=50){
			if (empty($getPost) OR strlen($getPost) < $valMin OR strlen($getPost) > $valMax){
						echo $getName . ' harus diisi, minimal '. $valMin .' karakter, maksimal '. $valMax .' karakter';
						die();
				}
		}
	}

	if( ! function_exists('ummuValidationCombo'))
	{
		function ummuValidationCombo($getPost, $getName){
			if (empty($getPost)){
						echo $getName . ' tidak boleh kosong';
						die();
				}
		}
	}
	
	if( ! function_exists('the_cetak'))
	{
		function the_cetak($getPost){
			$a['nmdin'] = 'DINAS PERHUBUNGAN';
			$a['almat'] = 'Jl. Raya Serayu Timur No. 129 Telp. (0286) 591331 Semampir';
			return $a[$getPost];
		}
	}

	if( ! function_exists('ummuKuduPodho'))
	{
		function ummuKuduPodho($post1, $post2, $pesan){
			if ($post1 != $post2){
						echo $pesan . ' tidak sama';
						die();
				}
		}
	}

if( ! function_exists('is_jenkel')){
	function is_jenkel($kel=false){
		$kl = array ('L' => 'Laki Laki', 'P' => 'Perempuan');
		$klo = $kel == true ? $kl[$kel] : $kl;
		return $klo;
	}
}
if( ! function_exists('is_rupiah')){
	function is_rupiah($r){
			$duit = "Rp " . number_format($r,2,',','.');
			return $duit;
	}
}

if( ! function_exists('is_koma')){
	function is_koma($r){
			$duit = "Rp " . number_format($r,2,',','.');
			return $duit;
	}
}
if( ! function_exists('is_tanpanol')){
	function is_tanpanol($r){
			$duit = number_format($r,0,',','.');
			return $duit;
	}
}

if( ! function_exists('is_no_rp')){
	function is_no_rp($r){
			$duit = number_format($r,0,',','.');
			return $duit;
	}
}

function inacbg_kel($kel){
	$_kel = array ('kelas_1' => 'Kelas I', 'kelas_2' => 'Kelas II', 'kelas_3' => 'Kelas III');
	return $_kel[$kel];
}
function is_hari($s){
	$hari = array (1 => 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu');
	return $hari[$s];
}

if( ! function_exists('the_time'))
{
	function the_time($time){
		$a = array ('01' => 'Januari',
			'02' => 'Febuari',
			'03' => 'Maret',
			'04' => 'April',
			'05' => 'Mei',
			'06' => 'Juni',
			'07' => 'Juli',
			'08' => 'Agustus',
			'09' => 'September',
			'10' => 'Oktober',
			'11' => 'November',
			'12' => 'Desember',
			'13' => '',
		);
		$getTime 	= explode (" ", $time);
		$getTime1 	= explode ("-", $getTime[0]);
		$getTime2	= $getTime1[2] .' '. $a[$getTime1[1]] .' '. $getTime1[0] .' / '. $getTime[1];
		return $getTime2;
	}
}

if( ! function_exists('the_bulan'))
{
	function the_bulan($time=false){
		$a = array ('01' => 'Januari',
			'02' => 'Februari',
			'03' => 'Maret',
			'04' => 'April',
			'05' => 'Mei',
			'06' => 'Juni',
			'07' => 'Juli',
			'08' => 'Agustus',
			'09' => 'September',
			'10' => 'Oktober',
			'11' => 'November',
			'12' => 'Desember',
		);
		return $time == false ? $a : $a[$time];
	}
}

if( ! function_exists('clean_data'))
{
	function clean_data($dat){
		//$clean = strip_tags(trim($dat));
		return $dat;
	}
}

if( ! function_exists('is_tingkat'))
{
	function is_tingkat($dat=false){
		$clean = range('A', 'E');
		if($dat == true){
			return $clean[$dat];
		} else {
			return $clean;
		}
		
	}
}

if( ! function_exists('is_type_akomodasi'))
{
	function is_type_akomodasi($dat=false){
		$clean = array('1x Perjalanan', 'Harian');
		return $clean;
	}
}

if( ! function_exists('is_akses_level'))
{
	function is_akses_level($dat=false){
		$clean = array('Administrator', 'Verifikator', 'Operator');
		return $clean;
	}
}


function get_time($str, $option=NULL){
	// convert the date to unix timestamp
	list($date, $time) = explode(' ', $str);
	list($year, $month, $day) = explode('-', $date);
	list($hour, $minute, $second) = explode(':', $time);

	$timestamp = mktime($hour, $minute, $second, $month, $day, $year);
	$now = time();
	$blocks = array(
	array('name'=>'Tahun', 'amount' => 60*60*24*365),
	array('name'=>'Bulan', 'amount' => 60*60*24*31),
	array('name'=>'Minggu', 'amount' => 60*60*24*7),
	array('name'=>'Hari', 'amount' => 60*60*24),
	array('name'=>'Jam', 'amount' => 60*60),
	array('name'=>'Menit', 'amount' => 60),
	array('name'=>'Detik', 'amount' => 1)
	);

	if($timestamp > $now) $string_type = ' tersisa';
	else $string_type = ' '.'yang lalu';

	$diff = abs($now-$timestamp);

	if($option=='smsd_check')
	{
		return $diff;	
	}
	else
	{
		if($diff < 60)
		{
			return "Kurang dari satu menit yang lalu";
		}
		else
		{
			$levels = 1;
			$current_level = 1;
			$result = array();
			foreach($blocks as $block)
			{
				if ($current_level > $levels) { break; }
				if ($diff/$block['amount'] >= 1)
				{
					$amount = floor($diff/$block['amount']);
					$plural = '';
					//if ($amount>1) {$plural='s';} else {$plural='';}
					$result[] = $amount.' '.$block['name'].$plural;
					$diff -= $amount*$block['amount'];
					$current_level+=1;	
				}
			}
			$res = implode(' ',$result).''.$string_type;
			return $res;
		}
	}	
}   

function get_umur($str, $option=NULL){
	// convert the date to unix timestamp
	list($date, $time) = explode(' ', $str);
	list($year, $month, $day) = explode('-', $date);
	list($hour, $minute, $second) = explode(':', $time);

	$timestamp = mktime($hour, $minute, $second, $month, $day, $year);
	$now = time();
	$blocks = array(
	array('name'=>'Tahun', 'amount' => 60*60*24*365),
	array('name'=>'Bulan', 'amount' => 60*60*24*31),
	array('name'=>'Hari', 'amount' => 60*60*24)
	);

	$diff = abs($now-$timestamp);
			$levels = 1;
			$current_level = 1;
			$result = array();
			foreach($blocks as $block)
			{
				if ($diff/$block['amount'] >= 1)
				{
					$amount = floor($diff/$block['amount']);
					$plural = '';
					//if ($amount>1) {$plural='s';} else {$plural='';}
					$result[] = $amount.' '.$block['name'].$plural;
					$diff -= $amount*$block['amount'];
					$current_level+=1;	
				}
			}
			$res = implode(', ',$result);
			return $res;
}  

function get_umur_jg($str, $option=NULL){
	// convert the date to unix timestamp
	list($date, $time) = explode(' ', $str);
	list($year, $month, $day) = explode('-', $date);
	list($hour, $minute, $second) = explode(':', $time);

	$timestamp = mktime($hour, $minute, $second, $month, $day, $year);
	$now = time();
	$blocks = array(
	array('name'=>'TH', 'amount' => 60*60*24*365),
	array('name'=>'BL', 'amount' => 60*60*24*31),
	);

	$diff = abs($now-$timestamp);
			$levels = 1;
			$current_level = 1;
			$result = array();
			foreach($blocks as $block)
			{
				if ($diff/$block['amount'] >= 1)
				{
					$amount = floor($diff/$block['amount']);
					$plural = '';
					//if ($amount>1) {$plural='s';} else {$plural='';}
					$result[] = $amount.' '.$block['name'].$plural;
					$diff -= $amount*$block['amount'];
					$current_level+=1;	
				}
			}
			$res = implode(' ',$result);
			return $res;
}   

function get_selisih($str, $akhir){
	// convert the date to unix timestamp
	list($date, $time) = explode(' ', $str);
	list($year, $month, $day) = explode('-', $date);
	list($hour, $minute, $second) = explode(':', $time);
	//rubah tanggala akhir
	list($tgl, $waktu) = explode(' ', $akhir);
	list($thn, $bln, $hr) = explode('-', $tgl);
	list($jam, $mnit, $dtik) = explode(':', $waktu);
	$skrg  		= mktime($jam, $mnit, $dtik, $bln, $hr, $thn);
	$timestamp 	= mktime($hour, $minute, $second, $month, $day, $year);
	//$now = time();
	$blocks = array(
	array('name'=>'Hari', 'amount' => 60*60*24),
	array('name'=>'Jam', 'amount' => 60*60),
	);

	$diff = abs($skrg-$timestamp);
			$levels = 1;
			$current_level = 1;
			$result = array();
			foreach($blocks as $block)
			{
				if ($diff/$block['amount'] >= 1)
				{
					$amount = floor($diff/$block['amount']);
					$plural = '';
					//if ($amount>1) {$plural='s';} else {$plural='';}
					$result[] = $amount.' '.$block['name'].$plural;
					$diff -= $amount*$block['amount'];
					$current_level+=1;	
				}
			}
			$res = implode(', ',$result);
			if(count($result) == '1'){
				$sd = explode(' ', $result[0]);
				if($sd[1] == 'Hari'){
					$result[1] = '0 Jam';
					return $result;
				} else {
					return $result;
				}
			} else if(count($result) == '2'){
				return $result;
			} else {
				return $result;
			}
}   

function is_encript($s){
	$x = 'vikoshaperdana'. md5(md5(md5(md5($s) .'vikosha') .'Perdana') .'encript by smoker') . md5($s);
	return $x;
}

function terbilang_get_valid($str,$from,$to,$min=1,$max=9){
	$val=false;
	$from=($from<0)?0:$from;
	for ($i=$from;$i<$to;$i++){
		if (((int) $str{$i}>=$min)&&((int) $str{$i}<=$max)) $val=true;
	}
	return $val;
}

function Ngomongya($x)
{
  $abil = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
  if ($x < 12)
    return " " . $abil[$x];
  elseif ($x < 20)
    return Ngomongya($x - 10) . "belas";
  elseif ($x < 100)
    return Ngomongya($x / 10) . " puluh" . Ngomongya($x % 10);
  elseif ($x < 200)
    return " seratus" . Ngomongya($x - 100);
  elseif ($x < 1000)
    return Ngomongya($x / 100) . " ratus" . Ngomongya($x % 100);
  elseif ($x < 2000)
    return " seribu" . Ngomongya($x - 1000);
  elseif ($x < 1000000)
    return Ngomongya($x / 1000) . " ribu" . Ngomongya($x % 1000);
  elseif ($x < 1000000000)
    return Ngomongya($x / 1000000) . " juta" . Ngomongya($x % 1000000);
}

function terbilang_get_str($i,$str,$len){
	$numA=array("","satu","dua","tiga","empat","lima","enam","tujuh","delapan","sembilan");
	$numB=array("","se","dua ","tiga ","empat ","lima ","enam ","tujuh ","delapan ","sembilan ");
	$numC=array("","satu ","dua ","tiga ","empat ","lima ","enam ","tujuh ","delapan ","sembilan ");
	$numD=array(0=>"puluh",1=>"belas",2=>"ratus",4=>"ribu", 7=>"juta", 10=>"milyar", 13=>"triliun");
	$buf="";
	$pos=$len-$i;
	switch($pos){
		case 1:
				if (!terbilang_get_valid($str,$i-1,$i,1,1))
					$buf=$numA[(int) $str{$i}];
			break;
		case 2:	case 5: case 8: case 11: case 14:
				if ((int) $str{$i}==1){
					if ((int) $str{$i+1}==0)
						$buf=($numB[(int) $str{$i}]).($numD[0]);
					else
						$buf=($numB[(int) $str{$i+1}]).($numD[1]);
				}
				else if ((int) $str{$i}>1){
						$buf=($numB[(int) $str{$i}]).($numD[0]);
				}				
			break;
		case 3: case 6: case 9: case 12: case 15:
				if ((int) $str{$i}>0){
						$buf=($numB[(int) $str{$i}]).($numD[2]);
				}
			break;
		case 4: case 7: case 10: case 13:
				if (terbilang_get_valid($str,$i-2,$i)){
					if (!terbilang_get_valid($str,$i-1,$i,1,1))
						$buf=$numC[(int) $str{$i}].($numD[$pos]);
					else
						$buf=$numD[$pos];
				}
				else if((int) $str{$i}>0){
					if ($pos==4)
						$buf=($numB[(int) $str{$i}]).($numD[$pos]);
					else
						$buf=($numC[(int) $str{$i}]).($numD[$pos]);
				}
			break;
	}
	return $buf;
}
function toTerbilang($nominal){
	$buf="";
	$str=$nominal."";
	$len=strlen($str);
	for ($i=0;$i<$len;$i++){
		$buf=trim($buf)." ".terbilang_get_str($i,$str,$len);
	}
	return ucwords(trim($buf)) .' Rupiah';
}

function alasankeluar($ss=false){
	$kel = array('Kabur' => 'Kabur', 'Dirujuk' => 'Dirujuk', 'Persetujuan Dokter' => 'Persetujuan Dokter', 'Atas Permintaan Sendiri' => 'Atas Permintaan Sendiri', 'Meninggal' => 'Meninggal');
	if($ss){
	return $kel[$ss];
	} else {
		return $kel;
	}
}

function timezones($sw=false){
	$timezones = array (
		  '(GMT-12:00) International Date Line West' => 'Pacific/Wake',
		  '(GMT-11:00) Midway Island' => 'Pacific/Apia',
		  '(GMT-11:00) Samoa' => 'Pacific/Apia',
		  '(GMT-10:00) Hawaii' => 'Pacific/Honolulu',
		  '(GMT-09:00) Alaska' => 'America/Anchorage',
		  '(GMT-08:00) Pacific Time (US &amp; Canada); Tijuana' => 'America/Los_Angeles',
		  '(GMT-07:00) Arizona' => 'America/Phoenix',
		  '(GMT-07:00) Chihuahua' => 'America/Chihuahua',
		  '(GMT-07:00) La Paz' => 'America/Chihuahua',
		  '(GMT-07:00) Mazatlan' => 'America/Chihuahua',
		  '(GMT-07:00) Mountain Time (US &amp; Canada)' => 'America/Denver',
		  '(GMT-06:00) Central America' => 'America/Managua',
		  '(GMT-06:00) Central Time (US &amp; Canada)' => 'America/Chicago',
		  '(GMT-06:00) Guadalajara' => 'America/Mexico_City',
		  '(GMT-06:00) Mexico City' => 'America/Mexico_City',
		  '(GMT-06:00) Monterrey' => 'America/Mexico_City',
		  '(GMT-06:00) Saskatchewan' => 'America/Regina',
		  '(GMT-05:00) Bogota' => 'America/Bogota',
		  '(GMT-05:00) Eastern Time (US &amp; Canada)' => 'America/New_York',
		  '(GMT-05:00) Indiana (East)' => 'America/Indiana/Indianapolis',
		  '(GMT-05:00) Lima' => 'America/Bogota',
		  '(GMT-05:00) Quito' => 'America/Bogota',
		  '(GMT-04:00) Atlantic Time (Canada)' => 'America/Halifax',
		  '(GMT-04:00) Caracas' => 'America/Caracas',
		  '(GMT-04:00) La Paz' => 'America/Caracas',
		  '(GMT-04:00) Santiago' => 'America/Santiago',
		  '(GMT-03:30) Newfoundland' => 'America/St_Johns',
		  '(GMT-03:00) Brasilia' => 'America/Sao_Paulo',
		  '(GMT-03:00) Buenos Aires' => 'America/Argentina/Buenos_Aires',
		  '(GMT-03:00) Georgetown' => 'America/Argentina/Buenos_Aires',
		  '(GMT-03:00) Greenland' => 'America/Godthab',
		  '(GMT-02:00) Mid-Atlantic' => 'America/Noronha',
		  '(GMT-01:00) Azores' => 'Atlantic/Azores',
		  '(GMT-01:00) Cape Verde Is.' => 'Atlantic/Cape_Verde',
		  '(GMT) Casablanca' => 'Africa/Casablanca',
		  '(GMT) Edinburgh' => 'Europe/London',
		  '(GMT) Greenwich Mean Time : Dublin' => 'Europe/London',
		  '(GMT) Lisbon' => 'Europe/London',
		  '(GMT) London' => 'Europe/London',
		  '(GMT) Monrovia' => 'Africa/Casablanca',
		  '(GMT+01:00) Amsterdam' => 'Europe/Berlin',
		  '(GMT+01:00) Belgrade' => 'Europe/Belgrade',
		  '(GMT+01:00) Berlin' => 'Europe/Berlin',
		  '(GMT+01:00) Bern' => 'Europe/Berlin',
		  '(GMT+01:00) Bratislava' => 'Europe/Belgrade',
		  '(GMT+01:00) Brussels' => 'Europe/Paris',
		  '(GMT+01:00) Budapest' => 'Europe/Belgrade',
		  '(GMT+01:00) Copenhagen' => 'Europe/Paris',
		  '(GMT+01:00) Ljubljana' => 'Europe/Belgrade',
		  '(GMT+01:00) Madrid' => 'Europe/Paris',
		  '(GMT+01:00) Paris' => 'Europe/Paris',
		  '(GMT+01:00) Prague' => 'Europe/Belgrade',
		  '(GMT+01:00) Rome' => 'Europe/Berlin',
		  '(GMT+01:00) Sarajevo' => 'Europe/Sarajevo',
		  '(GMT+01:00) Skopje' => 'Europe/Sarajevo',
		  '(GMT+01:00) Stockholm' => 'Europe/Berlin',
		  '(GMT+01:00) Vienna' => 'Europe/Berlin',
		  '(GMT+01:00) Warsaw' => 'Europe/Sarajevo',
		  '(GMT+01:00) West Central Africa' => 'Africa/Lagos',
		  '(GMT+01:00) Zagreb' => 'Europe/Sarajevo',
		  '(GMT+02:00) Athens' => 'Europe/Istanbul',
		  '(GMT+02:00) Bucharest' => 'Europe/Bucharest',
		  '(GMT+02:00) Cairo' => 'Africa/Cairo',
		  '(GMT+02:00) Harare' => 'Africa/Johannesburg',
		  '(GMT+02:00) Helsinki' => 'Europe/Helsinki',
		  '(GMT+02:00) Istanbul' => 'Europe/Istanbul',
		  '(GMT+02:00) Jerusalem' => 'Asia/Jerusalem',
		  '(GMT+02:00) Kyiv' => 'Europe/Helsinki',
		  '(GMT+02:00) Minsk' => 'Europe/Istanbul',
		  '(GMT+02:00) Pretoria' => 'Africa/Johannesburg',
		  '(GMT+02:00) Riga' => 'Europe/Helsinki',
		  '(GMT+02:00) Sofia' => 'Europe/Helsinki',
		  '(GMT+02:00) Tallinn' => 'Europe/Helsinki',
		  '(GMT+02:00) Vilnius' => 'Europe/Helsinki',
		  '(GMT+03:00) Baghdad' => 'Asia/Baghdad',
		  '(GMT+03:00) Kuwait' => 'Asia/Riyadh',
		  '(GMT+03:00) Moscow' => 'Europe/Moscow',
		  '(GMT+03:00) Nairobi' => 'Africa/Nairobi',
		  '(GMT+03:00) Riyadh' => 'Asia/Riyadh',
		  '(GMT+03:00) St. Petersburg' => 'Europe/Moscow',
		  '(GMT+03:00) Volgograd' => 'Europe/Moscow',
		  '(GMT+03:30) Tehran' => 'Asia/Tehran',
		  '(GMT+04:00) Abu Dhabi' => 'Asia/Muscat',
		  '(GMT+04:00) Baku' => 'Asia/Tbilisi',
		  '(GMT+04:00) Muscat' => 'Asia/Muscat',
		  '(GMT+04:00) Tbilisi' => 'Asia/Tbilisi',
		  '(GMT+04:00) Yerevan' => 'Asia/Tbilisi',
		  '(GMT+04:30) Kabul' => 'Asia/Kabul',
		  '(GMT+05:00) Ekaterinburg' => 'Asia/Yekaterinburg',
		  '(GMT+05:00) Islamabad' => 'Asia/Karachi',
		  '(GMT+05:00) Karachi' => 'Asia/Karachi',
		  '(GMT+05:00) Tashkent' => 'Asia/Karachi',
		  '(GMT+05:30) Chennai' => 'Asia/Calcutta',
		  '(GMT+05:30) Kolkata' => 'Asia/Calcutta',
		  '(GMT+05:30) Mumbai' => 'Asia/Calcutta',
		  '(GMT+05:30) New Delhi' => 'Asia/Calcutta',
		  '(GMT+05:45) Kathmandu' => 'Asia/Katmandu',
		  '(GMT+06:00) Almaty' => 'Asia/Novosibirsk',
		  '(GMT+06:00) Astana' => 'Asia/Dhaka',
		  '(GMT+06:00) Dhaka' => 'Asia/Dhaka',
		  '(GMT+06:00) Novosibirsk' => 'Asia/Novosibirsk',
		  '(GMT+06:00) Sri Jayawardenepura' => 'Asia/Colombo',
		  '(GMT+06:30) Rangoon' => 'Asia/Rangoon',
		  '(GMT+07:00) Bangkok' => 'Asia/Bangkok',
		  '(GMT+07:00) Hanoi' => 'Asia/Bangkok',
		  '(GMT+07:00) Jakarta' => 'Asia/Jakarta',
		  '(GMT+07:00) Krasnoyarsk' => 'Asia/Krasnoyarsk',
		  '(GMT+08:00) Beijing' => 'Asia/Hong_Kong',
		  '(GMT+08:00) Chongqing' => 'Asia/Hong_Kong',
		  '(GMT+08:00) Hong Kong' => 'Asia/Hong_Kong',
		  '(GMT+08:00) Irkutsk' => 'Asia/Irkutsk',
		  '(GMT+08:00) Kuala Lumpur' => 'Asia/Singapore',
		  '(GMT+08:00) Perth' => 'Australia/Perth',
		  '(GMT+08:00) Singapore' => 'Asia/Singapore',
		  '(GMT+08:00) Taipei' => 'Asia/Taipei',
		  '(GMT+08:00) Ulaan Bataar' => 'Asia/Irkutsk',
		  '(GMT+08:00) Urumqi' => 'Asia/Hong_Kong',
		  '(GMT+09:00) Osaka' => 'Asia/Tokyo',
		  '(GMT+09:00) Sapporo' => 'Asia/Tokyo',
		  '(GMT+09:00) Seoul' => 'Asia/Seoul',
		  '(GMT+09:00) Tokyo' => 'Asia/Tokyo',
		  '(GMT+09:00) Yakutsk' => 'Asia/Yakutsk',
		  '(GMT+09:30) Adelaide' => 'Australia/Adelaide',
		  '(GMT+09:30) Darwin' => 'Australia/Darwin',
		  '(GMT+10:00) Brisbane' => 'Australia/Brisbane',
		  '(GMT+10:00) Canberra' => 'Australia/Sydney',
		  '(GMT+10:00) Guam' => 'Pacific/Guam',
		  '(GMT+10:00) Hobart' => 'Australia/Hobart',
		  '(GMT+10:00) Melbourne' => 'Australia/Sydney',
		  '(GMT+10:00) Port Moresby' => 'Pacific/Guam',
		  '(GMT+10:00) Sydney' => 'Australia/Sydney',
		  '(GMT+10:00) Vladivostok' => 'Asia/Vladivostok',
		  '(GMT+11:00) Magadan' => 'Asia/Magadan',
		  '(GMT+11:00) New Caledonia' => 'Asia/Magadan',
		  '(GMT+11:00) Solomon Is.' => 'Asia/Magadan',
		  '(GMT+12:00) Auckland' => 'Pacific/Auckland',
		  '(GMT+12:00) Fiji' => 'Pacific/Fiji',
		  '(GMT+12:00) Kamchatka' => 'Pacific/Fiji',
		  '(GMT+12:00) Marshall Is.' => 'Pacific/Fiji',
		  '(GMT+12:00) Wellington' => 'Pacific/Auckland',
		  '(GMT+13:00) Nuku alofa' => 'Pacific/Tongatapu',
		);
	if($sw){
		return $timezones[$sw];
	} else {
		return $timezones;
	}
}
	//mulai clubnpde
	function is_page($key){
		$mm = str_replace('.html', '', $key);
		$kk = array('contact-us' => 'Contact Us', 'about' => 'About Us', 'privacy-policy' => 'Privacy Policy', 'disclaimer' => 'Disclaimer', 'term-of-service' => 'Term of Service');
		if($key != ""){
			return $kk[$mm];
		} else {
			return $kk;
		}
	}
	
	function job_type($key){
		$kk = array('parttime' => 'Part-time', 'new-grad' => 'New-Grad', 'subcontract' => 'Subcontract', 'contract' => 'Contract', 'temporary' => 'Temporary', 'volunteer' => 'Volunteer', 'permanent' => 'Permanent', 'fulltime' => 'Full-time', 'internship' => 'Internship');
		if($key != ""){
			return $kk[$key];
		} else {
			return $kk;
		}
	}

	