<?=@$this->load->view('header')?>

<!-- Main -->
<div id="main">

	<div class="row" style="margin-left: 0px; margin-right: 0px;">
		<div class="col-md-6" style="padding-right: 0px;">
		<br>
		
		<hr>
		<div class="col-md-12">
		    <h2 class="related-title"><?=@$judul?></h2>
		</div>


			<div class="col-md-12">
				<div class="card mb-12 box-shadow" style="margin-top: 10px;">
					<div class="card-body">
					
					
					
					<?php
								switch ($judul) {
									case "About Us":
										echo "
<p>We are a site that provides information about job vacancies in various countries, we believe there are job opportunities wherever you stand, and have the opportunity to develop the potential that is within each of us.<br></p>
<p>As a job portal, we strive to provide updated information about vacancies in various countries, we also provide field selection according to your abilities.<br>
With this opportunie.com portal, we hope to be able to help you in finding the right job and in accordance with the abilities you have.</p>
<p>Opportunie.com is a website providing information on job opportunities throughout the world. The data we present is valid and reliable data. <br>
The job opportunity data that we present has been integrated with a sophisticated system, so we always present the latest job opportunities.<br>
By keeping abreast of information technology in the world, we present information on job based websites. The goal we want to achieve is to facilitate access to job information for all people in the world.</p>

										";
										break;
									case "Privacy Policy":
										echo "
											<p>At opportunie.com we discuss the privacy of everyone who visits this website, the privacy document explains how the types of information we collect and record by opportunie.com</p>
<p><strong>Analytics</strong></p>
<p>We highly respect the privacy rights of all visitors, and therefore we do not use data that is privacy for certain purposes. In particular, we do not store personal data from visitors to opportunie.com, but there are some general data taken by Google. In this case there is a connection with Google because we use analytical services. General data taken for example such as your location, the device you are using, and the time of your visit. 
The data taken by Google Analytics is used wisely. Using this data we can see traffic on this website.</p>
<p><strong>Ad Partners</strong></p>
<p>We opportunie.com use <strong>Google</strong> advertising partners, may use cookies on our site and they have a privacy policy for their sites.</p>
										";
										break;
									case "Disclaimer":
										echo "
											<p>The information contained on this website is for general information purposes only. The information that opportunie.com provides will always strive to update our information, we make no representations or guarantees of any kind, express or implied, regarding the accuracy, depth, completeness, availability and suitability of respect to the website or information, or related graphics contained on the website for any purpose.</p>
<p>Whatever dependence you give to such information is itself at your own risk. Under no circumstances will we be responsible for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage arising from loss of data or profits arising from, or relating to, the use of the website this. Through this website you can link to other websites that are not under the control of opportunie.com.</p>
<p>We have no control over the nature, content and availability of these sites. The inclusion of any link does not always mean a recommendation or support the views expressed in it. All efforts made to keep the website running smoothly. However, opportunie.com is not responsible for, and will not be responsible for, the website is temporarily unavailable because technical issues are out of our control.</p>

										";
										break;
									case "Term of Service":
										echo "
										<p>
										There are no specific rules regarding data usage on this site. We allow it openly if you want to use content available at opportunie.com without having to specify the source of the data. However, we strongly recommend using wise data to avoid hoaxes and false information. In addition to the use of content, of course you are also allowed to disseminate information on this site to various media.</p>
											<p>We opportunie.com give overall access to our Wesbite portal, please access the information on our website, and we do not forbid if you want to link our url to your site, and we do not forbid you to retrieve data that is in opportunie.com, thank you.</p>
										";
										break;
									default:
										"";
								}
									
								?>
								
								
								
					</div>
				</div>
			</div>

		</div>

		

		<?=@$this->load->view('list')?>

		<?=@$this->load->view('sidebar')?>

	</div>

</div>

				

			</div>

		<footer id="sticky-footer" class="navbar-dark bg-danger py-4 text-white-50">
		    <div class="container text-center">
		      	<small>
		      		Copyright &copy; Opportunie.com - 
		      		<a href="<?=@base_url('job/page/about')?>"><strong>About</strong></a> | 
		      		<a href="<?=@base_url('job/page/privacy-policy')?>"><strong>Privacy Policy</strong></a> | 
		      		<a href="<?=@base_url('job/page/disclaimer')?>"><strong>Disclaimer</strong></a> | 
		      		<a href="<?=@base_url('job/page/term-of-service')?>"><strong>Term Of Service</strong></a>
		  		</small>
		    </div>
		  </footer>

		<!-- Scripts -->
		<script src="<?php echo base_url();?>assets/jquery/jquery.slim.min.js"></script>
		<script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>

	</body>
</html>
