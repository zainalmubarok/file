<style type="text/css">
  .btn {
    margin-bottom: 5px;
  }
</style>

<?php
  $su = explode('.',$_SERVER[HTTP_HOST]);
  if (strlen($su[0]) > 2){
    $st = 'us';
  }else{
    $st = $su[0];
  }
  $lg = $this->uri->language($st);  
?>

<?php if (strlen($su[0]) > 2){ ?> 

<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  	<!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/alabama" title="view posts under state Alabama">Alabama</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/alaska" title="view posts under state Alaska">Alaska</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/arizona" title="view posts under state Arizona">Arizona</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/arkansas" title="view posts under state Arkansas">Arkansas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/california" title="view posts under state California">California</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/colorado" title="view posts under state Colorado">Colorado</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/connecticut" title="view posts under state Connecticut">Connecticut</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/delaware" title="view posts under state Delaware">Delaware</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/florida" title="view posts under state Florida">Florida</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/georgia" title="view posts under state Georgia">Georgia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hawaii" title="view posts under state Hawaii">Hawaii</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/idaho" title="view posts under state Idaho">Idaho</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/illinois" title="view posts under state Illinois">Illinois</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/indiana" title="view posts under state Indiana">Indiana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/iowa" title="view posts under state Iowa">Iowa</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kansas" title="view posts under state Kansas">Kansas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kentucky" title="view posts under state Kentucky">Kentucky</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/louisiana" title="view posts under state Louisiana">Louisiana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/maine" title="view posts under state Maine">Maine</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/maryland" title="view posts under state Maryland">Maryland</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/massachusetts" title="view posts under state Massachusetts">Massachusetts</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/michigan" title="view posts under state Michigan">Michigan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/minnesota" title="view posts under state Minnesota">Minnesota</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mississippi" title="view posts under state Mississippi">Mississippi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/missouri" title="view posts under state Missouri">Missouri</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/montana" title="view posts under state Montana">Montana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nebraska" title="view posts under state Nebraska">Nebraska</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nevada" title="view posts under state Nevada">Nevada</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-hampshire" title="view posts under state New Hampshire">New Hampshire</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-jersey" title="view posts under state New Jersey">New Jersey</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-mexico" title="view posts under state New Mexico">New Mexico</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/new-york" title="view posts under state New York">New York</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/north-carolina" title="view posts under state North Carolina">North Carolina</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/north-dakota" title="view posts under state North Dakota">North Dakota</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ohio" title="view posts under state Ohio">Ohio</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/oklahoma" title="view posts under state Oklahoma">Oklahoma</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/oregon" title="view posts under state Oregon">Oregon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pennsylvania" title="view posts under state Pennsylvania">Pennsylvania</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rhode-island" title="view posts under state Rhode Island">Rhode Island</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/south-carolina" title="view posts under state South Carolina">South Carolina</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/south-dakota" title="view posts under state South Dakota">South Dakota</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tennessee" title="view posts under state Tennessee">Tennessee</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/texas" title="view posts under state Texas">Texas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/utah" title="view posts under state Utah">Utah</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/vermont" title="view posts under state Vermont">Vermont</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/virginia" title="view posts under state Virginia">Virginia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/washington" title="view posts under state Washington">Washington</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/west-virginia" title="view posts under state West Virginia">West Virginia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/wisconsin" title="view posts under state Wisconsin">Wisconsin</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/wyoming" title="view posts under state Wyoming">Wyoming</a> <br />

        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="view posts under category Biotech">Biotech
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/broadcast-journalism" title="view posts under category Broadcast - Journalism">Broadcast - Journalism
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/business-development" title="view posts under category Business Development">Business Development
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/education-teaching" title="view posts under category Education - Teaching">Education - Teaching
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/entry-level-new-grad" title="view posts under category Entry Level - New Grad">Entry Level - New Grad
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/executive" title="view posts under category Executive">Executive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/facilities" title="view posts under category Facilities">Facilities
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="view posts under category Franchise ">Franchise 
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/human-resources" title="view posts under category Human Resources">Human Resources
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/information-technology" title="view posts under category Information Technology">Information Technology
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/installation-maint-repair" title="view posts under category Installation - Maint - Repair">Installation - Maint - Repair
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/insurance" title="view posts under category Insurance">Insurance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/inventory" title="view posts under category Inventory">Inventory
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal" title="view posts under category Legal">Legal
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="view posts under category Legal Admin">Legal Admin
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/management" title="view posts under category Management">Management
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/manufacturing" title="view posts under category Manufacturing">Manufacturing
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="view posts under category Marketing">Marketing
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/media-journalism-newspaper" title="view posts under category Media - Journalism - Newspaper">Media - Journalism - Newspaper
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/nonprofit-social-services" title="view posts under category Nonprofit - Social Services">Nonprofit - Social Services
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/nurse" title="view posts under category Nurse ">Nurse 
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/other" title="view posts under category Other">Other
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/pharmaceutical" title="view posts under category Pharmaceutical">Pharmaceutical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/professional-services" title="view posts under category Professional Services">Professional Services
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/purchasing-procurement" title="view posts under category Purchasing - Procurement">Purchasing - Procurement
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/qa-quality-control" title="view posts under category QA - Quality Control">QA - Quality Control
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/real-estate" title="view posts under category Real Estate">Real Estate
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/research" title="view posts under category Research">Research
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-food-service" title="view posts under category Restaurant - Food Service">Restaurant - Food Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/science" title="view posts under category Science">Science
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/skilled-labor-trades" title="view posts under category Skilled Labor - Trades">Skilled Labor - Trades
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/strategy-planning" title="view posts under category Strategy - Planning">Strategy - Planning
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/supply-chain" title="view posts under category Supply Chain">Supply Chain
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecommunications" title="view posts under category Telecommunications">Telecommunications
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/training" title="view posts under category Training">Training
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warehouse" title="view posts under category Warehouse">Warehouse
  </a>

        </div>
      </div>
    </div>
  </div>

</div>

  <?php } ?>

<?php if ($st == 'id'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
    
    <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in City</h5>
        <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banda-aceh" title="Lowongan Di Kota Banda Aceh">Banda Aceh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/langsa" title="Lowongan Di Kota Langsa">Langsa</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/lhokseumawe" title="Lowongan Di Kota Lhokseumawe">Lhokseumawe</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/meulaboh" title="Lowongan Di Kota Meulaboh">Meulaboh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sabang" title="Lowongan Di Kota Sabang">Sabang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/subulussalam" title="Lowongan Di Kota Subulussalam">Subulussalam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/denpasar" title="Lowongan Di Kota Denpasar">Denpasar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pangkalpinang" title="Lowongan Di Kota Pangkalpinang">Pangkalpinang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/cilegon" title="Lowongan Di Kota Cilegon">Cilegon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/serang" title="Lowongan Di Kota Serang">Serang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tangerang-selatan" title="Lowongan Di Kota Tangerang Selatan">Tangerang Selatan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tangerang" title="Lowongan Di Kota Tangerang">Tangerang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bengkulu" title="Lowongan Di Kota Bengkulu">Bengkulu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/gorontalo" title="Lowongan Di Kota Gorontalo">Gorontalo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-barat" title="Lowongan Di Kota Jakarta Barat">Jakarta Barat</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-pusat" title="Lowongan Di Kota Jakarta Pusat">Jakarta Pusat</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-selatan" title="Lowongan Di Kota Jakarta Selatan">Jakarta Selatan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-timur" title="Lowongan Di Kota Jakarta Timur">Jakarta Timur</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jakarta-utara" title="Lowongan Di Kota Jakarta Utara">Jakarta Utara</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sungai-penuh" title="Lowongan Di Kota Sungai Penuh">Sungai Penuh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jambi" title="Lowongan Di Kota Jambi">Jambi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bandung" title="Lowongan Di Kota Bandung">Bandung</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bekasi" title="Lowongan Di Kota Bekasi">Bekasi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bogor" title="Lowongan Di Kota Bogor">Bogor</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/cimahi" title="Lowongan Di Kota Cimahi">Cimahi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/cirebon" title="Lowongan Di Kota Cirebon">Cirebon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/depok" title="Lowongan Di Kota Depok">Depok</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sukabumi" title="Lowongan Di Kota Sukabumi">Sukabumi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tasikmalaya" title="Lowongan Di Kota Tasikmalaya">Tasikmalaya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banjar" title="Lowongan Di Kota Banjar">Banjar</a>
      <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/magelang" title="Lowongan Di Kota Magelang">Magelang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pekalongan" title="Lowongan Di Kota Pekalongan">Pekalongan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/purwokerto" title="Lowongan Di Kota Purwokerto">Purwokerto</a>  
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/salatiga" title="Lowongan Di Kota Salatiga">Salatiga</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/semarang" title="Lowongan Di Kota Semarang">Semarang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/surakarta" title="Lowongan Di Kota Surakarta">Surakarta</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tegal" title="Lowongan Di Kota Tegal">Tegal</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/batu" title="Lowongan Di Kota Batu">Batu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/blitar" title="Lowongan Di Kota Blitar">Blitar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kediri" title="Lowongan Di Kota Kediri">Kediri</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/madiun" title="Lowongan Di Kota Madiun">Madiun</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/malang" title="Lowongan Di Kota Malang">Malang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mojokerto" title="Lowongan Di Kota Mojokerto">Mojokerto</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pasuruan" title="Lowongan Di Kota Pasuruan">Pasuruan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/probolinggo" title="Lowongan Di Kota Probolinggo">Probolinggo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/surabaya" title="Lowongan Di Kota Surabaya">Surabaya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pontianak" title="Lowongan Di Kota Pontianak">Pontianak</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/singkawang" title="Lowongan Di Kota Singkawang">Singkawang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banjarbaru" title="Lowongan Di Kota Banjarbaru">Banjarbaru</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/banjarmasin" title="Lowongan Di Kota Banjarmasin">Banjarmasin</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palangkaraya" title="Lowongan Di Kota Palangkaraya">Palangkaraya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/balikpapan" title="Lowongan Di Kota Balikpapan">Balikpapan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bontang" title="Lowongan Di Kota Bontang">Bontang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/samarinda" title="Lowongan Di Kota Samarinda">Samarinda</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tarakan" title="Lowongan Di Kota Tarakan">Tarakan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/batam" title="Lowongan Di Kota Batam">Batam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tanjungpinang" title="Lowongan Di Kota Tanjungpinang">Tanjungpinang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bandar-lampung" title="Lowongan Di Kota Bandar Lampung">Bandar Lampung</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/metro" title="Lowongan Di Kota Metro">Metro</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ternate" title="Lowongan Di Kota Ternate">Ternate</a>
      <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tidore-kepulauan" title="Lowongan Di Kota Tidore Kepulauan">Tidore Kepulauan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ambon" title="Lowongan Di Kota Ambon">Ambon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tual" title="Lowongan Di Kota Tual">Tual</a>
   <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bima" title="Lowongan Di Kota Bima">Bima</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mataram" title="Lowongan Di Kota Mataram">Mataram</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kupang" title="Lowongan Di Kota Kupang">Kupang</a>  
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sorong" title="Lowongan Di Kota Sorong">Sorong</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jayapura" title="Lowongan Di Kota Jayapura">Jayapura</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/dumai" title="Lowongan Di Kota Dumai">Dumai</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pekanbaru" title="Lowongan Di Kota Pekanbaru">Pekanbaru</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/makassar" title="Lowongan Di Kota Makassar">Makassar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palopo" title="Lowongan Di Kota Palopo">Palopo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/parepare" title="Lowongan Di Kota Parepare">Parepare</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palu" title="Lowongan Di Kota Palu">Palu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bau-bau" title="Lowongan Di Kota Bau-Bau">Bau-Bau</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kendari" title="Lowongan Di Kota Kendari">Kendari</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bitung" title="Lowongan Di Kota Bitung">Bitung</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kotamobagu" title="Lowongan Di Kota Kotamobagu">Kotamobagu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/manado" title="Lowongan Di Kota Manado">Manado</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tomohon" title="Lowongan Di Kota Tomohon">Tomohon</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bukittinggi" title="Lowongan Di Kota Bukittinggi">Bukittinggi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/padang" title="Lowongan Di Kota Padang">Padang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/padangpanjang" title="Lowongan Di Kota Padangpanjang">Padangpanjang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pariaman" title="Lowongan Di Kota Pariaman">Pariaman</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/payakumbuh" title="Lowongan Di Kota Payakumbuh">Payakumbuh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sawahlunto" title="Lowongan Di Kota Sawahlunto">Sawahlunto</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/solok" title="Lowongan Di Kota Solok">Solok</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/lubuklinggau" title="Lowongan Di Kota Lubuklinggau">Lubuklinggau</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pagaralam" title="Lowongan Di Kota Pagaralam">Pagaralam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/palembang" title="Lowongan Di Kota Palembang">Palembang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/prabumulih" title="Lowongan Di Kota Prabumulih">Prabumulih</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/binjai" title="Lowongan Di Kota Binjai">Binjai</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/medan" title="Lowongan Di Kota Medan">Medan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/padang-sidempuan" title="Lowongan Di Kota Padang Sidempuan">Padang Sidempuan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pematangsiantar" title="Lowongan Di Kota Pematangsiantar">Pematangsiantar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sibolga" title="Lowongan Di Kota Sibolga">Sibolga</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tanjungbalai" title="Lowongan Di Kota Tanjungbalai">Tanjungbalai</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tebingtinggi" title="Lowongan Di Kota Tebingtinggi">Tebingtinggi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/yogyakarta" title="Lowongan Di Kota Yogyakarta">Yogyakarta</a>

        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="view posts under category Biotech">Biotech
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/broadcast-journalism" title="view posts under category Broadcast - Journalism">Broadcast - Journalism
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/business-development" title="view posts under category Business Development">Business Development
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/education-teaching" title="view posts under category Education - Teaching">Education - Teaching
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/entry-level-new-grad" title="view posts under category Entry Level - New Grad">Entry Level - New Grad
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/executive" title="view posts under category Executive">Executive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/facilities" title="view posts under category Facilities">Facilities
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="view posts under category Franchise ">Franchise 
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/human-resources" title="view posts under category Human Resources">Human Resources
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/information-technology" title="view posts under category Information Technology">Information Technology
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/installation-maint-repair" title="view posts under category Installation - Maint - Repair">Installation - Maint - Repair
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/insurance" title="view posts under category Insurance">Insurance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/inventory" title="view posts under category Inventory">Inventory
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal" title="view posts under category Legal">Legal
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="view posts under category Legal Admin">Legal Admin
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/management" title="view posts under category Management">Management
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/manufacturing" title="view posts under category Manufacturing">Manufacturing
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="view posts under category Marketing">Marketing
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/media-journalism-newspaper" title="view posts under category Media - Journalism - Newspaper">Media - Journalism - Newspaper
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/nonprofit-social-services" title="view posts under category Nonprofit - Social Services">Nonprofit - Social Services
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/nurse" title="view posts under category Nurse ">Nurse 
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/other" title="view posts under category Other">Other
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/pharmaceutical" title="view posts under category Pharmaceutical">Pharmaceutical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/professional-services" title="view posts under category Professional Services">Professional Services
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/purchasing-procurement" title="view posts under category Purchasing - Procurement">Purchasing - Procurement
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/qa-quality-control" title="view posts under category QA - Quality Control">QA - Quality Control
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/real-estate" title="view posts under category Real Estate">Real Estate
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/research" title="view posts under category Research">Research
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-food-service" title="view posts under category Restaurant - Food Service">Restaurant - Food Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/science" title="view posts under category Science">Science
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/skilled-labor-trades" title="view posts under category Skilled Labor - Trades">Skilled Labor - Trades
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/strategy-planning" title="view posts under category Strategy - Planning">Strategy - Planning
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/supply-chain" title="view posts under category Supply Chain">Supply Chain
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecommunications" title="view posts under category Telecommunications">Telecommunications
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/training" title="view posts under category Training">Training
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warehouse" title="view posts under category Warehouse">Warehouse
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'br'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sao-paulo" title="Job opportunities in Sao Paulo">São Paulo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rio-de-janeiro" title="Job opportunities in Rio de Janeiro">Rio de Janeiro</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/minas-gerais" title="Job opportunities in Minas Gerais">Minas Gerais</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pernambuco" title="Job opportunities in Pernambuco">Pernambuco</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/federal-district" title="Job opportunities in Federal District">Federal District</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rio-grande-do-sul" title="Job opportunities in Rio Grande do Sul">Rio Grande do Sul</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bahia" title="Job opportunities in Bahia">Bahia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ceara" title="Job opportunities in Ceará">Ceará</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/parana" title="Job opportunities in Parana">Paraná</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Goiás" title="Job opportunities in Goiás">Goiás</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Belém" title="Job opportunities in Belém">Belém</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Manaus" title="Job opportunities in Manaus">Manaus</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Campinas" title="Job opportunities in Campinas">Campinas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Vitória" title="Job opportunities in Vitória">Vitória</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/natal" title="Job opportunities in Natal">Natal</a>
  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'ca'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in Provinces</h5>
        <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Ontario" title="Job opportunities in Ontario">Ontario</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Quebec" title="Job opportunities in Quebec">Quebec</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Nova-Scotia" title="Job opportunities in Nova Scotia">Nova Scotia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/British-Columbia" title="Job opportunities in British Columbia">British Columbia</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/Alberta" title="Job opportunities in Alberta">Alberta</a>
  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'cn'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
    <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in Provinces</h5>
        <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/anhui" title="Job opportunities in Anhui">Anhui</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/fujian" title="Job opportunities in Fujian">Fujian</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/gansu" title="Job opportunities in Gansu">Gansu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/guangdong" title="Job opportunities in Guangdong">Guangdong</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/guangxi" title="Job opportunities in Guangxi">Guangxi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/guizhou" title="Job opportunities in Guizhou">Guizhou</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/henan" title="Job opportunities in Henan">Henan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hubei" title="Job opportunities in Hubei">Hubei</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hunan" title="Job opportunities in Hunan">Hunan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jiangsu" title="Job opportunities in Jiangsu">Jiangsu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jiangxi" title="Job opportunities in Jiangxi">Jiangxi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/shaanxi" title="Job opportunities in Shaanxi">Shaanxi</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/shandong" title="Job opportunities in Shandong">Shandong</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/shanxi" title="Job opportunities in Shanxi">Shanxi</a>
  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'au'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in Cities</h5>
        <div class="justify-content-between align-items-center">
            
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sydney" title="Job opportunities in Sydney">Sydney</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/melbourne" title="Job opportunities in Melbourne">Melbourne</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/brisbane" title="Job opportunities in Brisbane">Brisbane</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/perth" title="Job opportunities in Perth">Perth</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/adelaide" title="Job opportunities in Adelaide">Adelaide</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/gold-coast" title="Job opportunities in Gold Coast">Gold Coast</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/newcastle" title="Job opportunities in Newcastle">Newcastle</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/canberra" title="Job opportunities in Canberra">Canberra</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/wollongong" title="Job opportunities in Wollongong">Wollongong</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sunshine Coast" title="Job opportunities in Sunshine Coast">Sunshine Coast</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hobart" title="Job opportunities in Hobart">Hobart</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/geelong" title="Job opportunities in Geelong">Geelong</a>
  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'de'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">
            
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/baden-württemberg" title="Job opportunities in Baden-Württemberg">Baden-Württemberg</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bavaria" title="Job opportunities in Bavaria">Bavaria</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/berlin" title="Job opportunities in Berlin">Berlin</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/brandenburg" title="Job opportunities in Brandenburg">Brandenburg</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bremen" title="Job opportunities in Bremen">Bremen</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hamburg" title="Job opportunities in Hamburg">Hamburg</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hesse" title="Job opportunities in Hesse">Hesse</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mecklenburg-vorpommern" title="Job opportunities in Mecklenburg-Vorpommern">Mecklenburg-Vorpommern</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/niedersachsen" title="Job opportunities in Niedersachsen">Niedersachsen</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nordrhein-Westfalen" title="Job opportunities in Nordrhein-Westfalen">Nordrhein-Westfalen</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rhineland-palatinate" title="Job opportunities in Rhineland-Palatinate">Rhineland-Palatinate</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/saarland" title="Job opportunities in Saarland">Saarland</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sachsen" title="Job opportunities in Sachsen">Sachsen</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/saxony-anhalt" title="Job opportunities in Saxony-Anhalt">Saxony-Anhalt</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/schleswig-holstein" title="Job opportunities in Schleswig-Holstein">Schleswig-Holstein</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/thuringia" title="Job opportunities in Thuringia">Thuringia</a>
  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>


<?php if ($st == 'in'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">
            
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/andhra-pradesh" title="Job opportunities in Andhra Pradesh">Andhra Pradesh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/arunachal-pradesh" title="Job opportunities in Arunachal Pradesh">Arunachal Pradesh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/assam" title="Job opportunities in Assam">Assam</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bihar" title="Job opportunities in Bihar">Bihar</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/chhattisgarh" title="Job opportunities in Chhattisgarh">Chhattisgarh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/goa" title="Job opportunities in Goa">Goa</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/gujarat" title="Job opportunities in Gujarat">Gujarat</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/haryana" title="Job opportunities in Haryana">Haryana</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/himachal-pradesh" title="Job opportunities in Himachal Pradesh">Himachal Pradesh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jharkhand" title="Job opportunities in Jharkhand">Jharkhand</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/karnataka" title="Job opportunities in Karnataka">Karnataka</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kerala" title="Job opportunities in Kerala">Kerala</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/madhya-pradesh" title="Job opportunities in Madhya Pradesh">Madhya Pradesh</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/maharashtra" title="Job opportunities in Maharashtra">Maharashtra</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/manipur" title="Job opportunities in Manipur">Manipur</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/meghalaya" title="Job opportunities in Meghalaya">Meghalaya</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mizoram" title="Job opportunities in Mizoram">Mizoram</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nagaland" title="Job opportunities in Nagaland">Nagaland</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/odisha" title="Job opportunities in Odisha">Odisha</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/punjab" title="Job opportunities in Punjab">Punjab</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rajasthan" title="Job opportunities in Rajasthan">Rajasthan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sikkim" title="Job opportunities in Sikkim">Sikkim</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tamil-nadu" title="Job opportunities in Tamil Nadu">Tamil Nadu</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tripura" title="Job opportunities in Tripura">Tripura</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/uttar Pradesh" title="Job opportunities in Uttar Pradesh">Uttar Pradesh</a>
  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'jp'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>市内の雇用機会</h5>
        <div class="justify-content-between align-items-center">
          
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/東京" title="Job opportunities in 東京">東京</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/横浜" title="Job opportunities in 横浜">横浜</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/大阪" title="Job opportunities in 大阪">大阪</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/名古屋" title="Job opportunities in 名古屋">名古屋</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/札幌" title="Job opportunities in 札幌">札幌</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/福岡県" title="Job opportunities in 福岡県">福岡県</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/神戸" title="Job opportunities in 神戸">神戸</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/川崎" title="Job opportunities in 川崎">川崎</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/京都" title="Job opportunities in 京都">京都</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/さいたま" title="Job opportunities in さいたま">さいたま</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/広島県" title="Job opportunities in 広島県">広島県</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/仙台" title="Job opportunities in 仙台">仙台</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/千葉" title="Job opportunities in 千葉">千葉</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/北九州" title="Job opportunities in 北九州">北九州</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/堺" title="Job opportunities in 堺">堺</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/新潟" title="Job opportunities in 新潟">新潟</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/浜松" title="Job opportunities in 浜松">浜松</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/熊本" title="Job opportunities in 熊本">熊本</a>

  
        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'my'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/johor" title="Job opportunities in Johor">Johor</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kedah" title="Job opportunities in Kedah">Kedah</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/kelantan" title="Job opportunities in Kelantan">Kelantan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/malacca" title="Job opportunities in Malacca">Malacca</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/negeri-sembilan" title="Job opportunities in Negeri Sembilan">Negeri Sembilan</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/pahang" title="Job opportunities in Pahang">Pahang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/penang" title="Job opportunities in Penang">Penang</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/perak" title="Job opportunities in Perak">Perak</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/perlis" title="Job opportunities in Perlis">Perlis</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sabah" title="Job opportunities in Sabah">Sabah</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sarawak" title="Job opportunities in Sarawak">Sarawak</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/selangor" title="Job opportunities in Selangor">Selangor</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/terengganu" title="Job opportunities in Terengganu">Terengganu</a>

  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>


<?php if ($st == 'mx'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">

  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/aguascalientes" title="Job opportunities in Aguascalientes">Aguascalientes</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/baja-california" title="Job opportunities in Baja California">Baja California</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/campeche" title="Job opportunities in Campeche">Campeche</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/chiapas" title="Job opportunities in Chiapas">Chiapas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/chihuahua" title="Job opportunities in Chihuahua">Chihuahua</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/coahuila" title="Job opportunities in Coahuila">Coahuila</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/colima" title="Job opportunities in Colima">Colima</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/durango" title="Job opportunities in Durango">Durango</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/guanajuato" title="Job opportunities in Guanajuato">Guanajuato</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/guerrero" title="Job opportunities in Guerrero">Guerrero</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hidalgo" title="Job opportunities in Hidalgo">Hidalgo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jalisco" title="Job opportunities in Jalisco">Jalisco</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mexico-city" title="Job opportunities in Mexico City">Mexico City</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/michoacán" title="Job opportunities in Michoacán">Michoacán</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/morelos" title="Job opportunities in Morelos">Morelos</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nayarit" title="Job opportunities in Nayarit">Nayarit</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nuevo-león" title="Job opportunities in Nuevo León">Nuevo León</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/oaxaca" title="Job opportunities in Oaxaca">Oaxaca</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/puebla" title="Job opportunities in Puebla">Puebla</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/querétaro" title="Job opportunities in Querétaro">Querétaro</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/quintana Roo" title="Job opportunities in Quintana Roo">Quintana Roo</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/san-luis-potosí" title="Job opportunities in San Luis Potosí">San Luis Potosí</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sinaloa" title="Job opportunities in Sinaloa">Sinaloa</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sonora" title="Job opportunities in Sonora">Sonora</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tabasco" title="Job opportunities in Tabasco">Tabasco</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tamaulipas" title="Job opportunities in Tamaulipas">Tamaulipas</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/veracruz" title="Job opportunities in Veracruz">Veracruz</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/yucatán" title="Job opportunities in Yucatán">Yucatán</a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/zacatecas" title="Job opportunities in Zacatecas">Zacatecas</a>


  
        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">


  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="view posts under category Accounting">Accounting
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/admin-clerical" title="view posts under category Admin & Clerical">Admin & Clerical
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="view posts under category Automotive">Automotive
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="view posts under category Banking">Banking
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="view posts under category Construction">Construction
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/consultant" title="view posts under category Consultant">Consultant
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="view posts under category Customer Service">Customer Service
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="view posts under category Design">Design
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="view posts under category Distribution - Shipping">Distribution - Shipping
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="view posts under category Engineering">Engineering
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/finance" title="view posts under category Finance">Finance
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="view posts under category General Business">General Business
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="view posts under category General Labor">General Labor
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="view posts under category Government">Government
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="view posts under category Grocery">Grocery
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="view posts under category Health Care">Health Care
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="view posts under category Hotel - Hospitality">Hotel - Hospitality
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="view posts under category Retail">Retail
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="view posts under category Sales">Sales
  </a>
  <a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="view posts under category Transportation">Transportation
  </a>
  </a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>

<?php if ($st == 'ar'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in Cities</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/buenos-aires" title="Buenos Aires"> Buenos Aires</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/córdoba" title="Córdoba"> Córdoba</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rosario" title="Rosario"> Rosario</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mendoza" title="Mendoza"> Mendoza</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tucumán" title="Tucumán"> Tucumán</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/la-plata" title="La Plata"> La Plata</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/mar-del-plata" title="Mar del Plata"> Mar del Plata</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/salta" title="Salta"> Salta</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/santa-fe" title="Santa Fe"> Santa Fe</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/san-juan" title="San Juan"> San Juan</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/resistencia" title="Resistencia"> Resistencia</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/santiago-del-estero" title="Santiago del Estero"> Santiago del Estero</a>

        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">
            
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/contabilidad" title="Contabilidad"> Contabilidad</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotor" title="Automotor"> Automotor</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bancario" title="Bancario"> Bancario</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotecnología" title="Biotecnología"> Biotecnología</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/desarrollo-de-negocios" title="Desarrollo de negocios"> Desarrollo de negocios</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construcción" title="Construcción"> Construcción</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/servicio-al-cliente" title="Servicio al Cliente"> Servicio al Cliente</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/diseño" title="Diseño"> Diseño</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribución-envío" title="Distribución - Envío"> Distribución - Envío</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/educación-enseñanza" title="Educación - Enseñanza"> Educación - Enseñanza</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/ingenieria" title="Ingenieria"> Ingenieria</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franquicia" title="Franquicia"> Franquicia</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/negocio-general" title="Negocio general"> Negocio general</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/trabajo-general" title="Trabajo general"> Trabajo general</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/gobierno" title="Gobierno"> Gobierno</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/tienda-de-comestibles" title="Tienda de comestibles"> Tienda de comestibles</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/cuidado-de-la-salud" title="Cuidado de la salud"> Cuidado de la salud</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitalidad" title="Hotel - Hospitalidad"> Hotel - Hospitalidad</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/recursos-humanos" title="Recursos humanos"> Recursos humanos</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/tecnologías-de-la-información" title="Tecnologías de la información"> Tecnologías de la información</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/administrador-legal" title="Administrador legal"> Administrador legal</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/administración" title="administración"> administración</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/fabricación" title="Fabricación"> Fabricación</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/márketing" title="Márketing"> Márketing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bienes-raíces" title="Bienes raíces"> Bienes raíces</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/investigación" title="Investigación"> Investigación</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurante-servicio-de-comida" title="Restaurante - Servicio de comida"> Restaurante - Servicio de comida</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/al-por-menor" title="Al por menor"> Al por menor</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/ventas" title="Ventas"> Ventas</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecomunicaciones" title="Telecomunicaciones"> Telecomunicaciones</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/formación" title="Formación"> Formación</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transporte" title="Transporte"> Transporte</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/almacén" title="Almacén"> Almacén</a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>


<?php if ($st == 'at'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in States</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/vorarlberg" title="Vorarlberg"> Vorarlberg</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/vienna" title="Vienna"> Vienna</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/upper-austria" title="Upper Austria"> Upper Austria</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/tyrol" title="Tyrol"> Tyrol</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/styria" title="Styria"> Styria</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/salzburg" title="Salzburg"> Salzburg</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/lower-austria" title="Lower Austria"> Lower Austria</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/carinthia" title="Carinthia"> Carinthia</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/burgenland" title="Burgenland"> Burgenland</a>

        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/buchhaltung" title="Buchhaltung"> Buchhaltung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="Automotive"> Automotive</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="Banking"> Banking</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="Biotech"> Biotech</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/geschäftsentwicklung" title="Geschäftsentwicklung"> Geschäftsentwicklung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/konstruktion" title="Konstruktion"> Konstruktion</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/kundendienst" title="Kundendienst"> Kundendienst</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="Design"> Design</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-versand" title="Distribution - Versand"> Distribution - Versand</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bildung-lehre" title="Bildung - Lehre"> Bildung - Lehre</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/maschinenbau" title="Maschinenbau"> Maschinenbau</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="Franchise"> Franchise</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/generelles-geschäft" title="Generelles Geschäft"> Generelles Geschäft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/allgemeine-arbeit" title="Allgemeine Arbeit"> Allgemeine Arbeit</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/regierung" title="Regierung"> Regierung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/lebensmittelgeschäft" title="Lebensmittelgeschäft"> Lebensmittelgeschäft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/gesundheitsvorsorge" title="Gesundheitsvorsorge"> Gesundheitsvorsorge</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-gastfreundschaft" title="Hotel - Gastfreundschaft"> Hotel - Gastfreundschaft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/humanressourcen" title="Humanressourcen"> Humanressourcen</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/informationstechnologie" title="Informationstechnologie"> Informationstechnologie</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="Legal Admin"> Legal Admin</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/verwaltung" title="Verwaltung"> Verwaltung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/herstellung" title="Herstellung"> Herstellung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="Marketing"> Marketing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grundeigentum" title="Grundeigentum"> Grundeigentum</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/forschung" title="Forschung"> Forschung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-lebensmittelservice" title="Restaurant - Lebensmittelservice"> Restaurant - Lebensmittelservice</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/verkauf" title="Verkauf"> Verkauf</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/der-umsatz" title="Der Umsatz"> Der Umsatz</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telekommunikation" title="Telekommunikation"> Telekommunikation</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/ausbildung" title="Ausbildung"> Ausbildung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transport" title="Transport"> Transport</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warenhaus" title="Warenhaus"> Warenhaus</a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>


<?php if ($st == 'be'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs in Provinces</h5>
        <div class="justify-content-between align-items-center">
            
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/west-flanders" title="West Flanders"> West Flanders</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/walloon-brabant" title="Walloon Brabant"> Walloon Brabant</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/namur" title="Namur"> Namur</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/luxembourg" title="Luxembourg"> Luxembourg</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/limburg" title="Limburg"> Limburg</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/liège" title="Liège"> Liège</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hainaut" title="Hainaut"> Hainaut</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/flemish-brabant" title="Flemish Brabant"> Flemish Brabant</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/east-flanders" title="East Flanders"> East Flanders</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/antwerp" title="Antwerp"> Antwerp</a>

        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/boekhouding" title="boekhouding"> boekhouding</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="Automotive"> Automotive</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bank" title="bank"> bank</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="Biotech"> Biotech</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/zakelijke-ontwikkeling" title="Zakelijke ontwikkeling"> Zakelijke ontwikkeling</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bouw" title="Bouw"> Bouw</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/klantenservice" title="Klantenservice"> Klantenservice</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/ontwerp" title="Ontwerp"> Ontwerp</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distributie-verzending" title="Distributie - verzending"> Distributie - verzending</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/onderwijs-lesgeven" title="Onderwijs - Lesgeven"> Onderwijs - Lesgeven</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bouwkunde" title="bouwkunde"> bouwkunde</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/stemrecht" title="stemrecht"> stemrecht</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/algemene-zaken" title="Algemene Zaken"> Algemene Zaken</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/algemeen-arbeid" title="Algemeen arbeid"> Algemeen arbeid</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/regering" title="Regering"> Regering</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/kruidenierswinkel" title="kruidenierswinkel"> kruidenierswinkel</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/gezondheidszorg" title="Gezondheidszorg"> Gezondheidszorg</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-gastvrijheid" title="Hotel - Gastvrijheid"> Hotel - Gastvrijheid</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/personeelszaken" title="Personeelszaken"> Personeelszaken</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/informatie-technologie" title="Informatie Technologie"> Informatie Technologie</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/juridische-beheerder" title="Juridische beheerder"> Juridische beheerder</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/beheer" title="Beheer"> Beheer</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/productie" title="Productie"> Productie</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/afzet" title="afzet"> afzet</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/onroerend-goed" title="Onroerend goed"> Onroerend goed</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/onderzoek" title="Onderzoek"> Onderzoek</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-voedselservice" title="Restaurant - voedselservice"> Restaurant - voedselservice</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/kleinhandel" title="Kleinhandel"> Kleinhandel</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/verkoop" title="verkoop"> verkoop</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecommunicatie" title="telecommunicatie"> telecommunicatie</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/opleiding" title="Opleiding"> Opleiding</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/vervoer" title="vervoer"> vervoer</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/magazijn" title="Magazijn"> Magazijn</a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>


<?php if ($st == 'bh'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Bahrain Municipality</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/al-hidd" title="Al Hidd"> Al Hidd</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/manama" title="Manama"> Manama</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/western-region" title="Western Region"> Western Region</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/central-region" title="Central Region"> Central Region</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/northern-region" title="Northern Region"> Northern Region</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/muharraq" title="Muharraq"> Muharraq</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/rifa-and-southern-region" title="Rifa and Southern Region"> Rifa and Southern Region</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jidd-haffs" title="Jidd Haffs"> Jidd Haffs</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hamad-town" title="Hamad Town"> Hamad Town</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/isa-town" title="Isa Town"> Isa Town</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/hawar-islands" title="Hawar Islands"> Hawar Islands</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/sitra" title="Sitra"> Sitra</a>

        </div>
      </div>
    </div>
  </div>


 <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="Accounting"> Accounting</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="Automotive"> Automotive</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="Banking"> Banking</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="Biotech"> Biotech</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/business-development" title="Business Development"> Business Development</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="Construction"> Construction</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="Customer Service"> Customer Service</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="Design"> Design</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="Distribution - Shipping"> Distribution - Shipping</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/education-teaching" title="Education - Teaching"> Education - Teaching</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="Engineering"> Engineering</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="Franchise"> Franchise</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="General Business"> General Business</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="General Labor"> General Labor</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="Government"> Government</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="Grocery"> Grocery</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="Health Care"> Health Care</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="Hotel - Hospitality"> Hotel - Hospitality</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/human-resources" title="Human Resources"> Human Resources</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/information-technology" title="Information Technology"> Information Technology</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="Legal Admin"> Legal Admin</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/management" title="Management"> Management</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/manufacturing" title="Manufacturing"> Manufacturing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="Marketing"> Marketing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/real-estate" title="Real Estate"> Real Estate</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/research" title="Research"> Research</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-food-service" title="Restaurant - Food Service"> Restaurant - Food Service</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="Retail"> Retail</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="Sales"> Sales</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecommunications" title="Telecommunications"> Telecommunications</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/training" title="Training"> Training</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="Transportation"> Transportation</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warehouse" title="Warehouse"> Warehouse</a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>


<?php if ($st == 'ch'){ ?>
<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>

  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Cantons Of Switzerland</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/aargau" title="Aargau"> Aargau</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/appenzell-ausserrhoden" title="Appenzell Ausserrhoden"> Appenzell Ausserrhoden</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/appenzell-innerrhoden" title="Appenzell Innerrhoden"> Appenzell Innerrhoden</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/basel-landschaft" title="Basel-Landschaft"> Basel-Landschaft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/basel-stadt" title="Basel-Stadt"> Basel-Stadt</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/bern" title="Bern"> Bern</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/fribourg" title="Fribourg"> Fribourg</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/geneva" title="Geneva"> Geneva</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/glarus" title="Glarus"> Glarus</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/grisons" title="Grisons"> Grisons</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/jura" title="Jura"> Jura</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/lucerne" title="Lucerne"> Lucerne</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/neuchâtel" title="Neuchâtel"> Neuchâtel</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/nidwalden" title="Nidwalden"> Nidwalden</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/obwalden" title="Obwalden"> Obwalden</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/schaffhausen" title="Schaffhausen"> Schaffhausen</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/schwyz" title="Schwyz"> Schwyz</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/solothurn" title="Solothurn"> Solothurn</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/st.-gallen" title="St. Gallen"> St. Gallen</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/thurgau" title="Thurgau"> Thurgau</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/ticino" title="Ticino"> Ticino</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/uri" title="Uri"> Uri</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/valais" title="Valais"> Valais</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/vaud" title="Vaud"> Vaud</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/zug" title="Zug"> Zug</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/state/zürich" title="Zürich"> Zürich</a>

        </div>
      </div>
    </div>
  </div>


  <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Find a Jobs Categories</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/buchhaltung" title="Buchhaltung"> Buchhaltung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="Automotive"> Automotive</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="Banking"> Banking</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="Biotech"> Biotech</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/geschäftsentwicklung" title="Geschäftsentwicklung"> Geschäftsentwicklung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/konstruktion" title="Konstruktion"> Konstruktion</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/kundendienst" title="Kundendienst"> Kundendienst</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="Design"> Design</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-versand" title="Distribution - Versand"> Distribution - Versand</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/bildung-lehre" title="Bildung - Lehre"> Bildung - Lehre</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/maschinenbau" title="Maschinenbau"> Maschinenbau</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="Franchise"> Franchise</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/generelles-geschäft" title="Generelles Geschäft"> Generelles Geschäft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/allgemeine-arbeit" title="Allgemeine Arbeit"> Allgemeine Arbeit</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/regierung" title="Regierung"> Regierung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/lebensmittelgeschäft" title="Lebensmittelgeschäft"> Lebensmittelgeschäft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/gesundheitsvorsorge" title="Gesundheitsvorsorge"> Gesundheitsvorsorge</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-gastfreundschaft" title="Hotel - Gastfreundschaft"> Hotel - Gastfreundschaft</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/humanressourcen" title="Humanressourcen"> Humanressourcen</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/informationstechnologie" title="Informationstechnologie"> Informationstechnologie</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="Legal Admin"> Legal Admin</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/verwaltung" title="Verwaltung"> Verwaltung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/herstellung" title="Herstellung"> Herstellung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="Marketing"> Marketing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grundeigentum" title="Grundeigentum"> Grundeigentum</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/forschung" title="Forschung"> Forschung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-lebensmittelservice" title="Restaurant - Lebensmittelservice"> Restaurant - Lebensmittelservice</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/verkauf" title="Verkauf"> Verkauf</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/der-umsatz" title="Der Umsatz"> Der Umsatz</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telekommunikation" title="Telekommunikation"> Telekommunikation</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/ausbildung" title="Ausbildung"> Ausbildung</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transport" title="Transport"> Transport</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warenhaus" title="Warenhaus"> Warenhaus</a>

        </div>
      </div>
    </div>
  </div>

</div>

<?php } ?>











<?php if ($st != 'us' AND $st != 'id' AND $st != 'br' AND $st != 'ca' AND $st != 'cn' AND $st != 'au' AND $st != 'de' AND $st != 'in' AND $st != 'jp' AND $st != 'my' AND $st != 'mx' AND $st != 'ar' AND $st != 'at' AND $st != 'be' AND $st != 'bh' AND $st != 'ch') { ?>

<div class="col-md-3" style="padding-right: 0px; padding-left: 0px;">      
  <br>
  
  <!-- Iklan Gambar Adsense -->
    <div class="col-md-12">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Iklan Gambar -->
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="ca-pub-5626121939364801"
             data-ad-slot="4985125804"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>
             (adsbygoogle = window.adsbygoogle || []).push({});
        </script>
    </div>
  
 <div class="col-md-12" style="margin-top: 10px;">
    <div class="card mb-12 box-shadow">
      <div class="card-body">
        <h5>Jobs Categories</h5>
        <div class="justify-content-between align-items-center">

<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/accounting" title="Accounting"> Accounting</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/automotive" title="Automotive"> Automotive</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/banking" title="Banking"> Banking</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/biotech" title="Biotech"> Biotech</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/business-development" title="Business Development"> Business Development</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/construction" title="Construction"> Construction</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/customer-service" title="Customer Service"> Customer Service</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/design" title="Design"> Design</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/distribution-shipping" title="Distribution - Shipping"> Distribution - Shipping</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/education-teaching" title="Education - Teaching"> Education - Teaching</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/engineering" title="Engineering"> Engineering</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/franchise" title="Franchise"> Franchise</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-business" title="General Business"> General Business</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/general-labor" title="General Labor"> General Labor</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/government" title="Government"> Government</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/grocery" title="Grocery"> Grocery</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/health-care" title="Health Care"> Health Care</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/hotel-hospitality" title="Hotel - Hospitality"> Hotel - Hospitality</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/human-resources" title="Human Resources"> Human Resources</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/information-technology" title="Information Technology"> Information Technology</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/legal-admin" title="Legal Admin"> Legal Admin</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/management" title="Management"> Management</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/manufacturing" title="Manufacturing"> Manufacturing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/marketing" title="Marketing"> Marketing</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/real-estate" title="Real Estate"> Real Estate</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/research" title="Research"> Research</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/restaurant-food-service" title="Restaurant - Food Service"> Restaurant - Food Service</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/retail" title="Retail"> Retail</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/sales" title="Sales"> Sales</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/telecommunications" title="Telecommunications"> Telecommunications</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/training" title="Training"> Training</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/transportation" title="Transportation"> Transportation</a>
<a class="btn btn-sm btn-outline-secondary" href="<?=@base_url()?>job/category/warehouse" title="Warehouse"> Warehouse</a>

        </div>
      </div>
    </div>
  </div>

</div>
<?php } ?>




