<!DOCTYPE HTML>

<html lang="en">
	<head>
	    <!-- Google Adsense -->
	    <script data-ad-client="ca-pub-5626121939364801" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	    
		<meta name="msvalidate.01" content="5A3D31B2B5827A9EEFC21F54C0DFA2DB" />
        <title><?=@$title?></title>
        <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/icon.png" type="image/x-icon" />
		<meta charset="utf-8" />
		
		<?php if(!$blockmeta){ ?>
        <meta name="description" content="<?=@$description?>">
        <meta name="keywords" content="<?=@$keyword?>">
        <?php } ?>
		<meta name="author" content="Opportunie.com - Job Opportunities">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<meta name="robots" content="all,follow">      
		<link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" />
		
		<!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-151336231-1"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'UA-151336231-1');
          gtag('config', 'UA-151394890-1');
        </script>

	</head>

	<body>

		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						<nav class="navbar navbar-expand-lg navbar-dark bg-danger sticky-top" style="position: sticky;">
						  <a class="navbar-brand" href="<?php echo base_url(); ?>">
						  	<img src="<?php echo base_url();?>assets/images/icon.png" width="30" height="30" class="d-inline-block align-top" alt="">
						  	<strong><?=@$name?></strong>
						  </a>
						  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
						    <span class="navbar-toggler-icon"></span>
						  </button>
						  <div class="collapse navbar-collapse" id="navbarNav">
						    <ul class="navbar-nav">
						      <li class="nav-item">
						        <a class="nav-link" href="<?=@base_url()?>">Home</a>
						      </li>
						      <li class="nav-item">
						        <a class="nav-link" href="<?=@base_url('job/maps/sitemap.xml')?>">Sitemap</a>
						      </li>
						    </ul>

						    <form class="form-inline my-2 my-lg-0 ml-auto" method="get" action="<?=@base_url('job/search/')?>">
						    	<input class="form-control mr-sm-2" name="q" placeholder="Job Title or Company">
						      	<input class="form-control mr-sm-2" name="l" placeholder="City, Province, or Region">
						      	<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search a Jobs</button>
						    </form>

						  </div>
						</nav>
					</header>

