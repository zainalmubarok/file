<style>
.aaa {
  list-style-type: none;
}
</style>
<!-- Sidebar -->
					<section id="" class="post">
								<?php
								$su = explode('.',$_SERVER[HTTP_HOST]);
								if (strlen($su[0]) > 2){
									$st = 'us';
								}else{
									$st = $su[0];
								}
								$lg = $this->uri->language($st);	
								?>
						<!-- Intro -->
							<section id="intro" <?php if($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my') { echo 'style="height:520px"'; }?>>
                            	<h2>Countries</h2>
                                
                                <form action="" method="post">
                                	<select name="countries" onchange="this.form.submit()">
                                         <option <?php echo ($st == "au") ? 'selected="selected"' : ''; ?> value="au">Australia</option>
                                         <option <?php echo ($st == "cn") ? 'selected="selected"' : ''; ?> value="cn">China</option>
                                         <option <?php echo ($st == "id") ? 'selected="selected"' : ''; ?> value="id">Indonesia</option>
                                         <option <?php echo ($st == "jp") ? 'selected="selected"' : ''; ?> value="jp">Japan</option>
                                         <option <?php echo ($st == "my") ? 'selected="selected"' : ''; ?> value="my">Malaysia</option>
                                         <option <?php echo ($st == "nz") ? 'selected="selected"' : ''; ?> value="nz">New Zealand</option>
                                         <option <?php echo ($st == "sg") ? 'selected="selected"' : ''; ?> value="sg">Singapore</option>
                                         <option <?php echo ($st == "se") ? 'selected="selected"' : ''; ?> value="se">Sweden</option>
                                         <option <?php echo ($st == "ch") ? 'selected="selected"' : ''; ?> value="ch">Switzerland</option>
                                         <option <?php echo ($st == "gb") ? 'selected="selected"' : ''; ?> value="gb">United Kingdom</option>
                                         <option <?php echo ($st == "us") ? 'selected="selected"' : ''; ?> value="us">United States</option>
                                    </select>
                                </form>
                                
								<h2>Job Type</h2>
                                
                                <div class="float_center">
                                    <ul class="child aaa">
                                      <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l28']?>" title="<?=$lg['l28']?> " ><?=ucwords(strtolower($lg['l28']))?> </a> 
                                        <?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        / 
                                        <a href="<?=@base_url()?>job/type/internship" title="Internship " >Internship </a>
                                        <?php
											}
										?>
                                    </li>
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l29']?>" title="<?=$lg['l29']?> " ><?=ucwords(strtolower($lg['l29']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/permanent" title="Permanent " >Permanent </a>
										<?php
											}
										?>
                                    </li>
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l30']?>" title="<?=$lg['l30']?> " ><?=ucwords(strtolower($lg['l30']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/volunteer" title="Volunteer " >Volunteer </a>
										<?php
											}
										?>
                                    </li>
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l31']?>" title="<?=$lg['l31']?> " ><?=ucwords(strtolower($lg['l31']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/temporary" title="Temporary " >Temporary </a>
										<?php
											}
										?>
                                    </li>
                                    
                                    </ul>
                                    <div class="clear"></div>
                                </div>
                                <div class="clear"></div>	
                                <div class="float_center">
                                    <ul class="child aaa">
                                     
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l32']?>" title="<?=$lg['l32']?> " ><?=ucwords(strtolower($lg['l32']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/contract" title="Contract " >Contract </a>
										<?php
											}
										?>
                                    </li>
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l33']?>" title="<?=$lg['l33']?> " ><?=ucwords(strtolower($lg['l33']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/subcontract" title="Subcontract " >Subcontract </a>
										<?php
											}
										?>
                                    </li>
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l34']?>" title="<?=$lg['l34']?> " ><?=ucwords(strtolower($lg['l34']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/new-grad" title="New Grad " >New Graduates </a>
										<?php
											}
										?>
                                    </li>
                                    <li>
                                        <a href="<?=@base_url()?>job/type/<?=$lg['l35']?>" title="<?=$lg['l35']?> " ><?=ucwords(strtolower($lg['l35']))?> </a> 
										<?php
											if ($st == 'cn' or $st == 'id' or $st == 'jp' or $st == 'my'){
										?>
                                        /
                                        <a href="<?=@base_url()?>job/type/part-time" title="Part time " >Part time </a>
										<?php
											}
										?>
                                    </li>
                                    </ul>
                                    <div class="clear"></div>
                                </div>
                                <br />
							</section>
                            
                            <section id="intro">
								
                                
						

						<!-- About -->
							
						<!-- Footer -->
							<section id="footer">
                            <ul class="icons">
                                <li><a href="<?=@base_url('job/page/about')?>"><strong>About</strong></a></li>
                                <li><a href="<?=@base_url('job/page/privacy-policy')?>"><strong>Privacy Policy</strong></a></li>
                                <li><a href="<?=@base_url('job/page/disclaimer')?>"><strong>Disclaimer</strong></a></li>
                                <li><a href="<?=@base_url('job/page/term-of-service')?>"><strong>Term Of Service</strong></a></li>
                            </ul>
								<!--<ul class="icons">
                                      <a href="<?php //echo base_url(); ?>disclaimer" class="dropdown" style="margin-right:10px">Disclaimer
                                      </a>
                                      <a href="<?php //echo base_url(); ?>privacypolice" class="dropdown" style="margin-right:10px">Privacy Police
                                      </a>
                                      <a href="<?php //echo base_url(); ?>termsofuse" class="dropdown" style="margin-right:10px">Terms Of Use
                                      </a>  
								</ul>-->
								<p class="copyright">&copy; Untitled 2018. <?=@$name?>. Design By: <a href="http://html5up.net">HTML5 UP</a>.</p>
							</section>

					</section>
