<footer id="sticky-footer" class="navbar-dark bg-danger py-4 text-white-50">
    <div class="container text-center">
      	<small>
      		Copyright &copy; Opportunie.com - 
      		<a href="<?=@base_url('job/page/about')?>"><strong>About</strong></a> | 
      		<a href="<?=@base_url('job/page/privacy-policy')?>"><strong>Privacy Policy</strong></a> | 
      		<a href="<?=@base_url('job/page/disclaimer')?>"><strong>Disclaimer</strong></a> | 
      		<a href="<?=@base_url('job/page/term-of-service')?>"><strong>Term Of Service</strong></a>
  		</small>
    </div>
  </footer>