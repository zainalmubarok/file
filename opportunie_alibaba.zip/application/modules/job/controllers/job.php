<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Job extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		ini_set('max_execution_time', 0);
		ini_set('max_input_time', 0);
		ini_set('memory_limit', '1024M');
	//	error_reporting(e_all, e_notice);
		$this->home_link = $this->uri->segment(1);
		$this->u1 = $this->uri->segment(1);
		$this->u2 = $this->uri->segment(2);
		$this->u3 = $this->uri->segment(3);
		$this->u4 = $this->uri->segment(4);
		$this->u5 = $this->uri->segment(5);
		$this->u6 = $this->uri->segment(6);
		//$st = (!empty($_POST['countries']) ?  : 'us');
//		$oy = (!empty($this->session->userdata('state')) ? $this->session->userdata('state') : $st);
		
		if (isset($_POST['countries'])){
			if ($_POST['countries'] == 'us'){
				redirect('https://opportunie.com/', 'refresh');
			}else{
				redirect('https://'.$_POST['countries'].'.opportunie.com/', 'refresh');
			}
		}
		
		$su = explode('.',$_SERVER[HTTP_HOST]);
		if (strlen($su[0]) > 2){
			$st = 'us';
		}else{
			$st = $su[0];
		}
		
		$ng = $this->uri->countries($st);
		$this->lg = $this->uri->language($st);	
		//echo $this->lg['l1'];
	//	ini_set('display_errors','On');
	//	error_reporting(E_ALL | E_STRICT);
		error_reporting(0);
		$this->load->driver('cache');
		//$this->session->userdata('name');
		//cuma ini yang dirubhah................................
		$this->negara = ''.$ng.'';
		$this->pubkey = "8893894946983875";
		$this->title = "Opportunie.com";
		$this->desc  = ''.$this->negara.' '.$this->lg['l1'].'';
		$this->state = ''.$st.'';
		$this->footer = ''.$this->lg['l1'].' '.$this->negara.' | '.$this->lg['l2'].' '.$this->negara.' | '.$this->lg['l3'].' | Copyright '.@date('Y').' @ <a href="http://'.$this->title.'/">'.$this->title.'</a>';
		//-----------------------------------------------------------
	}
	
	public function testid()
	{
	    /* var_dump('test');
	    die(); */
		$pub_id 	= $_GET['pub_id'];
		$uri 		= 'http://api.indeed.com/ads/apisearch?publisher='.$pub_id.'&q=a&start=1&limit=10&v=2';
		$sxml 		= simplexml_load_file($uri);
		$new 		= $sxml->results;

		if ($sxml->results) {
			echo "<pre>";
			var_dump($sxml->results);
			die();
		}else{
			echo "<pre>";
			var_dump($sxml->results);
			die();
		}
	}
	
	public function index(){
	    
	    /*$url = 'http://api.indeed.com/ads/apisearch?publisher=8893894946983875&q=a&l=&sort=date&radius=&st=&jt=&start=1&limit=10&fromage=&filter=&latlong=1&co=us&chnl=&userip=108.162.238.123&useragent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F80.0.3987.163+Safari%2F537.36&v=2';
	    $sxml = simplexml_load_file($url);
	    echo "<pre>";
	    var_dump($sxml);
	    die();*/
	    
		$data['title']       	= ''.$this->title.' - '.$this->lg['l1'].' '.$this->negara.' - '.$this->lg['l2'].' '.$this->negara.' - '.$this->lg['l3'].'';
		$data['description'] 	= ''.$this->lg['l4'].' '.$this->negara.' '. date('Y') .' | '.$this->lg['l5'].' '.$this->negara.' '.$this->lg['l7'].' '.$this->negara.' '.$this->lg['l8'].' '. date('Y') .' '.$this->lg['l9'].' '.$this->negara.' '.$this->lg['l6'].' '.$this->negara.'.';
		$data['keyword'] 		= ''.$this->negara.' '.$this->lg['l10'].', '.$this->negara.' '.$this->lg['l10'].' '. date('Y') .', '.$this->negara.' '.$this->lg['l11'].', '.$this->negara.' '.$this->lg['l11'].' '. date('Y') .', '.$this->negara.' '.$this->lg['l12'].', '.$this->negara.' '.$this->lg['l12'].' '. date('Y') .', '.$this->lg['l13'].' '.$this->negara.', '.$this->lg['l13'].' '.$this->negara.' '. date('Y') .', '.$this->lg['l8'].', '.$this->lg['l14'].' '.$this->negara .'';
		$data['name']			= $this->title;
		$this->load->view('index', $data);
	}
	public function state(){
		$nm = clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
		$nm = ucwords($nm);
		$data['title']       	= ''.$this->lg['l1'].' '. $nm .' - '.$this->lg['l2'].' '. $nm .' - '.$this->lg['l3'].' - '.$this->title.'';
		$data['description'] 	= ''.$this->lg['l4'].' '. $nm .' '. date('Y') .' | '.$this->lg['l5'].' '.$this->negara.' '.$this->lg['l7'].' '. $nm .' '.$this->lg['l8'].' '. date('Y') .' '.$this->lg['l9'].' '. $nm .' '.$this->lg['l6'].' '. $nm .'.';
		$data['keyword'] 		= ''. $nm .' '.$this->lg['l10'].', '. $nm .' '.$this->lg['l10'].' '. date('Y') .', '. $nm .' '.$this->lg['l11'].', '. $nm .' '.$this->lg['l11'].' '. date('Y') .', '. $nm .' '.$this->lg['l12'].', '. $nm .' '.$this->lg['l12'].' '. date('Y') .', '.$this->lg['l13'].' '. $nm .', '.$this->lg['l13'].' '. $nm .' '. date('Y') .', '.$this->lg['l8'].', '.$this->lg['l14'].' '.$this->negara .'';
		$data['name']			= $this->title;
		$this->load->view('state', $data);
	}
	public function city(){
		$nm = clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
		$nm = ucwords($nm);
		$data['title']       	= ''.$this->lg['l1'].' '. $nm .' - '.$this->lg['l2'].' '. $nm .' - '.$this->lg['l3'].' - '.$this->title.'';
		$data['description'] 	= ''.$this->lg['l4'].' '. $nm .' '. date('Y') .' | '.$this->lg['l5'].' '.$this->negara.' '.$this->lg['l7'].' '. $nm .' '.$this->lg['l8'].' '. date('Y') .' '.$this->lg['l9'].' '. $nm .' '.$this->lg['l6'].' '. $nm .'.';
		$data['keyword'] 		= ''. $nm .' '.$this->lg['l10'].', '. $nm .' '.$this->lg['l10'].' '. date('Y') .', '. $nm .' '.$this->lg['l11'].', '. $nm .' '.$this->lg['l11'].' '. date('Y') .', '. $nm .' '.$this->lg['l12'].', '. $nm .' '.$this->lg['l12'].' '. date('Y') .', '.$this->lg['l13'].' '. $nm .', '.$this->lg['l13'].' '. $nm .' '. date('Y') .', '.$this->lg['l8'].', '.$this->lg['l14'].' '.$this->negara .'';
		$this->load->view('city', $data);
	}
	public function category(){
		$nm = clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
		$nm = ucwords($nm);
		$data['title']       	= ''.$this->lg['l1'].' '. $nm .' - '.$this->lg['l2'].' '. $nm .' - '.$this->lg['l3'].' - '.$this->title.'';
		$data['description'] 	= ''.$this->lg['l4'].' '. $nm .' '. date('Y') .' | '.$this->lg['l5'].' '.$this->negara.' '.$this->lg['l7'].' '. $nm .' '.$this->lg['l8'].' '. date('Y') .' '.$this->lg['l9'].' '. $nm .' '.$this->lg['l6'].' '. $nm .'.';
		$data['keyword'] 		= ''. $nm .' '.$this->lg['l10'].', '. $nm .' '.$this->lg['l10'].' '. date('Y') .', '. $nm .' '.$this->lg['l11'].', '. $nm .' '.$this->lg['l11'].' '. date('Y') .', '. $nm .' '.$this->lg['l12'].', '. $nm .' '.$this->lg['l12'].' '. date('Y') .', '.$this->lg['l13'].' '. $nm .', '.$this->lg['l13'].' '. $nm .' '. date('Y') .', '.$this->lg['l8'].', '.$this->lg['l14'].' '.$this->negara .'';
		$data['name']			= $this->title;
		$this->load->view('category', $data);
	}
	public function company(){
		$nm = clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
		$nm = ucwords($nm);
		$data['title']       	= ''.$this->lg['l1'].' '. $nm .' - '.$this->lg['l2'].' '. $nm .' - '.$this->lg['l3'].' - '.$this->title.'';
		$data['description'] 	= ''.$this->lg['l4'].' '. $nm .' '. date('Y') .' | '.$this->lg['l5'].' '.$this->negara.' '.$this->lg['l7'].' '. $nm .' '.$this->lg['l8'].' '. date('Y') .' '.$this->lg['l9'].' '. $nm .' '.$this->lg['l6'].' '. $nm .'.';
		$data['keyword'] 		= ''. $nm .' '.$this->lg['l10'].', '. $nm .' '.$this->lg['l10'].' '. date('Y') .', '. $nm .' '.$this->lg['l11'].', '. $nm .' '.$this->lg['l11'].' '. date('Y') .', '. $nm .' '.$this->lg['l12'].', '. $nm .' '.$this->lg['l12'].' '. date('Y') .', '.$this->lg['l13'].' '. $nm .', '.$this->lg['l13'].' '. $nm .' '. date('Y') .', '.$this->lg['l8'].', '.$this->lg['l14'].' '.$this->negara .'';
		$data['name']			= $this->title;
		$this->load->view('company', $data);
	}
	public function type(){
		$nm = clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
		$nm = ucwords($nm);
		$data['title']       	= ''.$this->lg['l1'].' '. $nm .' - '.$this->lg['l2'].' '. $nm .' - '.$this->lg['l15'].' - '.$this->title.'';
		$data['description'] 	= ''.$this->lg['l4'].' '. $nm .' '. date('Y') .' | '.$this->lg['l5'].' '.$this->negara.' '.$this->lg['l7'].' '. $nm .' '.$this->lg['l8'].' '. date('Y') .' '.$this->lg['l9'].' '. $nm .' '.$this->lg['l6'].' '. $nm .'.';
		$data['keyword'] 		= ''. $nm .' '.$this->lg['l10'].', '. $nm .' '.$this->lg['l10'].' '. date('Y') .', '. $nm .' '.$this->lg['l11'].', '. $nm .' '.$this->lg['l11'].' '. date('Y') .', '. $nm .' '.$this->lg['l12'].', '. $nm .' '.$this->lg['l12'].' '. date('Y') .', '.$this->lg['l13'].' '. $nm .', '.$this->lg['l13'].' '. $nm .' '. date('Y') .', '.$this->lg['l8'].', '.$this->lg['l14'].' '.$this->negara .'';
		$data['name']			= $this->title;
		$this->load->view('type', $data);
	}
	public function page(){
		$data['title']       	= is_page($this->u3) .' - '.$this->title.'';
		$data['judul']       	= is_page($this->u3);
		$data['name']			= $this->title;
		$this->load->view('page', $data);
	}
	public function search(){
		if($_GET){
			$uri3 = $_GET['l'] == '' ? 'allcity' : clean_data(urlencode(strtolower(str_replace(" ", "-", SchCleanChar($_GET['l'])))));
			$uri4 = $_GET['q'] == '' ? 'alljobs' : clean_data(urlencode(strtolower(str_replace(" ", "-", SchCleanChar($_GET['q'])))));
			
			redirect(base_url('job/search/'. $uri3 .'/'. $uri4));
		}
		$wil = $this->uri->segment(3) == 'allcity' ? '' : clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(3)))));
		$pek = $this->uri->segment(4) == 'alljobs' ? '' : clean_data(urldecode(strtolower(str_replace("-", " ", $this->uri->segment(4)))));
		$data['description'] 	= ''.$this->lg['l18'].' '.  $pek .' '.$this->lg['l10'].' in '. $wil .' '. date('Y') .'. - '.$this->lg['l16'].' '. $pek .' '.$this->lg['l17'].' '.$this->negara.'';
		$data['keyword'] 		= $pek .' '.$this->lg['l5'].' '. $wil .' '. date('Y') .', '. $pek .' '.$this->lg['l8'].' '. date('Y') .', '. $pek .' '.$this->lg['l10'].' '. date('Y') .', '. $pek .' '.$this->lg['l19'].' '. date('Y') .', '. $pek .' '.$this->lg['l11'].' '. date('Y') .', '. $pek .' '.$this->lg['l20'].' '. date('Y') .', '. $pek .' '.$this->lg['l21'].' '. date('Y') .', '. $wil .' '.$this->lg['l10'].', '. $wil .' '.$this->lg['l19'].', '. $wil .' '.$this->lg['l11'].', '. $wil .' '.$this->lg['l20'].', '. $wil .' '.$this->lg['l21'].', '. $wil .' '.$this->lg['l8'].' '. date('Y') .', '. $wil .' '.$this->lg['l10'].' '. date('Y') .', '. $wil .' '.$this->lg['l19'].' '. date('Y') .', '. $wil .' '.$this->lg['l11'].' '. date('Y') .', '. $wil .' '.$this->lg['l20'].' '. date('Y') .', '. $wil .' '.$this->lg['l21'].' '. date('Y') .', '. $pek .' '.$this->lg['l4'].' '. $wil .', '. $pek .' '.$this->lg['l4'].' '. $wil .' '. date('Y') .', '. $pek .' '.$this->lg['l22'].' '. $wil .' '. date('Y') .', '. $pek .' '.$this->lg['l8'].' '.$this->lg['l23'].' '. $wil .' '. date('Y');
		$data['title']       	= $pek . ' '.$this->lg['l10'].' '.$this->lg['l24'].' '. $wil . ' '. date('Y');
		$data['judul']       	= $data['title'];
		$data['name']			= $this->title;
		$this->load->view('search', $data);
	}
	public function article(){
			$jobkey = $this->u3;
			$uri = 'http://api.indeed.com/ads/apigetjobs?publisher=8893894946983875&jobkeys='. $jobkey .'&v=2';
			$sxml = simplexml_load_file($uri);
			$dat = $sxml->results->result;
			foreach($dat as $rt){
				$data['judul']	     = (string)$rt->jobtitle;
				$data['company'] 	 = (string)$rt->company;
				$data['location'] 	 = (string)$rt->formattedLocation;
				$mm 				 = 'date';
				$data['date']		 = (string)$rt->$mm;
				$data['urlredirect'] = (string)$rt->url;
				$data['konten'] 	 = (string)str_replace("...", "", $rt->snippet) ;
			}
    		
		
			$data['title']       		= $data['judul'] .' - '. $data['company'] .' - '.$this->lg['l1'].' '.$this->negara.'';
        	$data['description']       	= $data['judul'] .' '.$this->lg['l10'].' '.$this->lg['l24'].' '. $data['company'] .' '.$this->lg['l25'].' '. $data['location'] .' - '.$this->lg['l1'].' '.$this->negara.' ';
        //	$data['keyword']       		= $data['judul'] .' '.$this->lg['l10'].' '. date('Y') .', '. $data['judul'] .' jobs '. date('Y') .', '. $data['judul'] .' '.$this->lg['l19'].' '. date('Y') .', '. $data['judul'] .' '.$this->lg['l11'].' '. date('Y') .', '. $data['judul'] .' '.$this->lg['l20'].' '. date('Y') .', '. $data['judul'] .' '.$this->lg['l21'].' '. date('Y') .', '.$this->negara .' '.$this->lg['l26'].' jobs '. date('Y') .', '.$this->negara .' Postal Service '.$this->lg['l10'].' '. date('Y') .', '.$this->negara .' Postal Service '.$this->lg['l19'].' '. date('Y') .', '.$this->negara .' Postal Service '.$this->lg['l11'].' '. date('Y') .', '.$this->negara .' Postal Service '.$this->lg['l20'].' '. date('Y') .', '.$this->negara .' Postal Service '.$this->lg['l21'].' '. date('Y') .' - '.$this->negara.' '.$this->lg['l1'].'';
			$data['name']			= $this->title;
        	$data['keyword']       		= 
        	     $data['judul'] .' '.$this->lg['l10'].' '. date('Y') .', '
        	    . $data['judul'] .' '.$this->lg['l8'].' '. date('Y') .', '
        	    . $data['judul'] .' '.$this->lg['l19'].' '. date('Y') .', '
        	    . $data['judul'] .' '.$this->lg['l11'].' '. date('Y') .', '
        	    . $data['judul'] .' '.$this->lg['l20'].' '. date('Y') .', '
        	    . $data['judul'] .' '.$this->lg['l21'].' '. date('Y') 
        	    ." "
        	     .$data['company'] .' '.$this->lg['l10'].' '. date('Y') .', '
        	    . $data['company'] .' '.$this->lg['l8'].' '. date('Y') .', '
        	    . $data['company'] .' '.$this->lg['l19'].' '. date('Y') .', '
        	    . $data['company'] .' '.$this->lg['l11'].' '. date('Y') .', '
        	    . $data['company'] .' '.$this->lg['l20'].' '. date('Y') .', '
        	    . $data['company'] .' '.$this->lg['l21'].' '. date('Y') 
        	     ." "
        	     .$data['location'] .' '.$this->lg['l10'].' '. date('Y') .', '
        	    . $data['location'] .' '.$this->lg['l8'].' '. date('Y') .', '
        	    . $data['location'] .' '.$this->lg['l19'].' '. date('Y') .', '
        	    . $data['location'] .' '.$this->lg['l11'].' '. date('Y') .', '
        	    . $data['location'] .' '.$this->lg['l20'].' '. date('Y') .', '
        	    . $data['location'] .' '.$this->lg['l21'].' '. date('Y') 
        	    .', '.$this->negara .' '.$this->lg['l26'].' '.$this->lg['l8'].' '. date('Y') 
        	    .', '.$this->negara .' '.$this->lg['l26'].' '.$this->lg['l10'].' '. date('Y') 
        	    .', '.$this->negara .' '.$this->lg['l26'].' '.$this->lg['l19'].' '. date('Y') 
        	    .', '.$this->negara .' '.$this->lg['l26'].' '.$this->lg['l11'].' '. date('Y') 
        	    .', '.$this->negara .' '.$this->lg['l26'].' '.$this->lg['l20'].' '. date('Y') 
        	    .', '.$this->negara .' '.$this->lg['l26'].' '.$this->lg['l21'].' '. date('Y') ;
    		$data['konten'] .= "<br /><br />". $data['keyword'] ."<br /><br />".$this->lg['l27']."";
		$this->load->view('article', $data);
	}
	public function maps(){
		$this->load->view('sitemap', $data);
	}
	
	/*public function testdata(){
	    $url = 'http://api.indeed.com/ads/apisearch?publisher=8893894946983875&q=a&l=&sort=date&radius=&st=&jt=&start=1&limit=10&fromage=&filter=&latlong=1&co=id&chnl=&v=2';
	    $sxml = simplexml_load_file($url);
	    print_r($sxml);
	    echo "<br>";
	    echo "<br>";
	    echo "<br>";
	    echo "Closed Parsing";
	    die();
	}
	
	public function infophp(){
	    phpinfo();
	}*/
	
}

